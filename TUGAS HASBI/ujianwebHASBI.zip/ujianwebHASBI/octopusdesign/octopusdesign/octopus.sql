-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24 Sep 2014 pada 06.38
-- Versi Server: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `octopus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_event`
--

CREATE TABLE IF NOT EXISTS `mst_event` (
  `id_event` int(11) NOT NULL AUTO_INCREMENT,
  `judul_event` varchar(100) NOT NULL,
  `isi_event` text NOT NULL,
  `tanggal_event` date DEFAULT NULL,
  `photo_event` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_event`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `mst_event`
--

INSERT INTO `mst_event` (`id_event`, `judul_event`, `isi_event`, `tanggal_event`, `photo_event`) VALUES
(1, 'bukber', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Buka Puasa Bersama diadakan setiap Tahun pada tanggal 17 Ramadhan bersama para karyawan dan pemilik.<br>', '2014-07-24', '92d0c751ca123ec75af1bda8710882ff.jpg'),
(4, 'Dinner Bersama PT. Info Media', 'Octopus Design di percaya sebagai pihak dokumentasi, acara Dinner bersama para pemegam saham di PT. Info Media<br><br>', '2014-05-01', '42bdc8912c29e1cf4341f7c555b19b18.jpg'),
(5, 'Wisata Akhir Tahun', 'Octopus design and photograph bukan hanya mementingkan kualitas dan kuantitas jasa yang dihasilkan serta mendapatkan keuntungan yang besar tapi merupakan perusahaan yang mementingkan hubungan antara pemilik dan karyawan serta para pelanggan setia.setiap akhir tahun octopus design menyelenggarakan acara wisata yang mengundang pelanggan yang loyal yang telah memenangkan undian,wisata kali ini di adakan di salah satu vila <br>di bogor selama 2 hari satu malam.<br>rangkaian acara di wisata ini :<br>1. wisata ke taman bunga cibodas.<br>2. acara bakar jagung bersama.<br>3. berenang<br>4. hiburan<br>', '2013-12-29', '7bd69847e2275117503a8977bec9e39a.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_jenisproduk`
--

CREATE TABLE IF NOT EXISTS `mst_jenisproduk` (
  `id_jenisproduk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jenisproduk` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_jenisproduk`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `mst_jenisproduk`
--

INSERT INTO `mst_jenisproduk` (`id_jenisproduk`, `nama_jenisproduk`, `keterangan`) VALUES
(2, 'cup', 'Cup Print Image'),
(3, 'Photo Pra Wedding OutDoor', ''),
(4, 'freestyle T-shirt', 't-shirt dengan design bebas'),
(5, 'Photo Studio Keluarga', ''),
(6, 'Photo Studio Sahabat', ''),
(7, 'Design dan Cetak Kartu Nama', 'Kartu Nama'),
(8, 'Design and Made Year Book ', ''),
(9, 'Photo Studio Graduation', ''),
(10, 'Banner', ''),
(11, 'Photo Booth', 'Wedding');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_karyawan`
--

CREATE TABLE IF NOT EXISTS `mst_karyawan` (
  `nik` int(11) NOT NULL,
  `nama_karyawan` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat_karyawan` varchar(100) NOT NULL,
  `jk_karyawan` varchar(20) NOT NULL,
  `email_karyawan` varchar(100) NOT NULL,
  `tlpn_karyawan` varchar(15) NOT NULL,
  `jabatan_karyawan` varchar(50) NOT NULL,
  `photo_karyawan` varchar(100) NOT NULL,
  PRIMARY KEY (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mst_karyawan`
--

INSERT INTO `mst_karyawan` (`nik`, `nama_karyawan`, `tgl_lahir`, `alamat_karyawan`, `jk_karyawan`, `email_karyawan`, `tlpn_karyawan`, `jabatan_karyawan`, `photo_karyawan`) VALUES
(101, 'indah', '0000-00-00', 'fbfvf', 'Perempuan', 'indahrahma0909@gmail.com', '089637793222', 'Karyawan Administrasi2', '27b8e888bb355e997bbbf5f712b3af22.jpg'),
(10101, 'Hanif', '0000-00-00', 'Bekasi Barat', 'Laki-laki', 'hanif@gmail.com', '02188962081', 'Pemilik', 'a865bdd4b8c6dd81264494dd4a905321.jpg'),
(10233, 'salwa', '2000-09-11', 'dfdef', 'Perempuan', 'indahrahma0909@gmail.com', '089637793222', 'Karyawan Marketing', '99e7654d6c834297caba28ee613a4898.jpg'),
(1001010, 'Panji', '1980-11-04', 'Pondok Gede', 'Laki-laki', 'panji.java@gmail.com', '021993838323', 'Kreatif Design', 'e900a2a0b30592b61166ae29b5f0b346.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_katalog`
--

CREATE TABLE IF NOT EXISTS `mst_katalog` (
  `id_katalog` int(11) NOT NULL AUTO_INCREMENT,
  `nama_katalog` varchar(100) NOT NULL,
  `link_katalog` varchar(100) NOT NULL,
  `tanggal_katalog` date NOT NULL,
  `id_jenisproduk` int(11) NOT NULL,
  PRIMARY KEY (`id_katalog`),
  KEY `fk_idk` (`id_jenisproduk`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `mst_katalog`
--

INSERT INTO `mst_katalog` (`id_katalog`, `nama_katalog`, `link_katalog`, `tanggal_katalog`, `id_jenisproduk`) VALUES
(1, 'Banner', 'www.twitter.com', '0000-00-00', 10),
(2, 'katalog cup', 'www.facebook.com', '2014-06-13', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_komunikasi`
--

CREATE TABLE IF NOT EXISTS `mst_komunikasi` (
  `id_komunikasi` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email_dari` varchar(50) DEFAULT NULL,
  `email_kepada` varchar(50) NOT NULL,
  `isi` text NOT NULL,
  `tgl_komunikasi` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id_komunikasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `mst_komunikasi`
--

INSERT INTO `mst_komunikasi` (`id_komunikasi`, `name`, `email_dari`, `email_kepada`, `isi`, `tgl_komunikasi`, `status`) VALUES
(7, 'indah', 'kamseupay107@gmail.com', '', 'hei studio', '2014-09-14 02:33:46', 'Menerima');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_member`
--

CREATE TABLE IF NOT EXISTS `mst_member` (
  `nik` int(11) NOT NULL,
  `nama_member` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat_member` varchar(100) NOT NULL,
  `jk_member` varchar(20) NOT NULL,
  `email_member` varchar(100) NOT NULL,
  `tlpn_member` varchar(15) NOT NULL,
  `photo_member` varchar(100) NOT NULL,
  `nama_bank` varchar(50) NOT NULL,
  `rekening_bank` varchar(30) NOT NULL,
  PRIMARY KEY (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mst_member`
--

INSERT INTO `mst_member` (`nik`, `nama_member`, `tgl_lahir`, `alamat_member`, `jk_member`, `email_member`, `tlpn_member`, `photo_member`, `nama_bank`, `rekening_bank`) VALUES
(1, 'nilam ayu', '0000-00-00', '																																												Bintaro																																								', 'Perempuan', 'nay.tari@gmail.com', '0821888494', '33fde7d41dd26f5f7f5167b2be0cbea6.jpg', 'BCA', '0939383');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_pemesanan`
--

CREATE TABLE IF NOT EXISTS `mst_pemesanan` (
  `id_pemesanan` int(11) NOT NULL AUTO_INCREMENT,
  `id_produk` int(11) NOT NULL,
  `jumlah_produk` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `tanggal_pemesanan` datetime NOT NULL,
  `nik` int(11) NOT NULL,
  `persetujuan` varchar(20) NOT NULL,
  PRIMARY KEY (`id_pemesanan`),
  KEY `fk_ip` (`id_produk`),
  KEY `fk_nm` (`nik`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `mst_pemesanan`
--

INSERT INTO `mst_pemesanan` (`id_pemesanan`, `id_produk`, `jumlah_produk`, `total_harga`, `tanggal_pemesanan`, `nik`, `persetujuan`) VALUES
(1, 9, 2, 200000, '2014-09-14 04:49:31', 1, 'Disetujui');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_produk`
--

CREATE TABLE IF NOT EXISTS `mst_produk` (
  `id_produk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_produk` varchar(100) NOT NULL,
  `id_jenisproduk` int(11) NOT NULL,
  `deskripsi` text NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `jumlah_produk` int(11) NOT NULL,
  `satuan_produk` varchar(30) NOT NULL,
  `dari_tanggal` date NOT NULL,
  `sampai_tanggal` date NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `persetujuan` varchar(20) NOT NULL,
  `jumlah_show` int(11) NOT NULL,
  PRIMARY KEY (`id_produk`),
  KEY `fk_ij` (`id_jenisproduk`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data untuk tabel `mst_produk`
--

INSERT INTO `mst_produk` (`id_produk`, `nama_produk`, `id_jenisproduk`, `deskripsi`, `harga_produk`, `jumlah_produk`, `satuan_produk`, `dari_tanggal`, `sampai_tanggal`, `kategori`, `photo`, `persetujuan`, `jumlah_show`) VALUES
(1, 'Gelas Sovenir', 2, 'Cup bergambar dengan gambar yang sesuai keinginan pelanggan<br>dapat dijadikan sovenir pernikahan,seminar,konser,meeting dan sekolah<br>', 10000, 1, 'Pieces', '2014-08-18', '2014-12-05', 'Reguler', '909a34e114213ba8e47f6a2279c094d9.jpg', 'Di Setujui', 27),
(3, 'Prawedding Outdoor Non Tempat', 3, 'Photo Prawedding Outdoor sangatlah romantis dan penuh memori untuk mengabadikan moment penuh kasih sayang menjelang pernikahan.<br>produk termasuk : <br>cetak foto 60 x 80 = 2 kali<br>Frame 60 X 80 = 2<br>cetak foto 20R = 3<br>cetak foto 5R = 4<br>CD =&nbsp; 1<br>', 1000000, 1, 'Package', '2014-08-26', '2014-11-19', 'Reguler', '22d2ec795579385e3c3900d71e87b25f.jpg', 'Di Setujui', 3),
(4, 'Prawedding Unik', 3, 'Photo Prawedding Outdoor dan Unik sangatlah romantis dan penuh memori \r\nuntuk mengabadikan moment penuh kasih sayang menjelang pernikahan.<br>produk termasuk : <br>cetak foto 60 x 80 = 2 kali<br>Frame 60 X 80 = 2<br>cetak foto 20R = 3<br>cetak foto 5R = 4<br>CD =&nbsp; 1<br>Make Up Pasangan<br>Properti Unik<br>* jika tema yang diinginkan tidak tersedia oleh perusahaan,maka akomodasi tambahan di tanggung pelanggan <br>										<br>', 2000000, 1, 'Package', '2014-08-23', '2014-11-12', 'Reguler', 'ff120eaaf03c61f40b4870da46faa536.jpg', 'Di Setujui', 2),
(5, 'Photostudio Keluarga Bahagia', 5, 'produk termasuk : <br>Photo = 10 kali<br>cetak foto 60 x 80 = 1 kali<br>Frame 60 X 80 = 1<br>cetak foto 10R = 3<br>CD =&nbsp; 1<br><br>', 300000, 1, 'Package', '2014-08-20', '2014-10-20', 'Reguler', '2e7b8fdfefa3f6b38a05e5fe115d659f.jpg', 'Di Setujui', 22),
(6, 'Photo Studio Sahabat Simple', 6, 'Photo Studio bersama sahabat dengan background simple namun cool<br>dengan harga promo<br>photo termasuk :<br>cetak 10 R x 1 gaya = 5 kali<br>CD = 1 kali<br>Foto = 10 Gaya<br>cetak 5 R x 2 Gaya = 5 kali<br><br>* untuk cetak tambahan di kenakan harga cetak foto normal per lembar<br>', 150000, 1, 'Package', '2014-08-13', '0000-00-00', 'Reguler', 'a7b7c60b01631930b885e3072bf0836a.jpg', 'Di Setujui', 2),
(7, 'Kartu Nama Bisnis', 7, 'Kartu nama bisnis dengan design kreatif menarik dapat menarik perhatian dan membantu meningkatkan citra diri di mata klien anda dengan <br>harga Rp. 75000 /100 lembar<br><br>', 75000, 100, '0', '2014-09-09', '2015-09-09', 'Promo', '1cac2d25a3c2ec335ac323ed8c3facfc.jpg', 'Di Setujui', 1),
(8, 'Year Book High School', 8, 'Ayo Buat Year book untuk mengenang masa-masa indah di SMA/SMK kamu<br>buku tahunan termasuk :<br>biaya photographer<br>biaya editing<br>cetak buku<br>CD<br>', 100000, 1, 'Buku', '2014-08-15', '2015-08-15', 'Reguler', '8003a9de6710b3a280bf2a969ff21ee3.jpg', 'Di Setujui', 1),
(9, 'Photo Studio Graduation Unik', 9, 'photo studio untuk mengabadikan masa-masa kelulusan bersama sahabat,pacar,orang tua dan kerabat dengan tema unik<br>include :<br>foto 8 kali gaya<br>cetak foto 15 R = 2 foto<br>Cetak foto 10 R = 2 foto<br>CD<br>', 100000, 1, '0', '2014-09-01', '2000-09-01', 'Promo', 'cab8ebe2e1fe3c39606374ef1c26619a.jpg', 'Di Setujui', 5),
(11, 'Design Banner', 10, 'Design Banner di Octopus Design akan memberikan kenyamanan bagi pengguna karena kualitas produk dan design akan sangat sesuai dan mencerminkan tujuan pelanggan<br>ukuran 2x3 meter<br>', 100000, 1, 'Banner', '2014-09-13', '2014-12-23', 'Reguler', 'e8abf675e294070ffdd3821d6af27127.jpg', 'Di Setujui', 3),
(12, 'Design Banner Seminar', 10, 'Design Banner di Octopus Design akan memberikan kenyamanan bagi pengguna\r\n karena kualitas produk dan design akan sangat sesuai dan mencerminkan \r\ntujuan pelanggan<br>ukuran 2 x 3 meter dan 1.5 x 2,5 meter<br>', 200000, 2, 'Banner', '2014-01-01', '2015-01-01', 'Promo', '1ee1366b37b6f8f6de4d809ac53d2d40.jpg', 'Di Setujui', 0),
(13, 'Photo Booth Wedding Sovenir', 11, 'Jadikan Photo Both sebagai sovenir pernikahan anda<br>Photo booth sudah termasuk:<br>1. alat kamera.<br>2. Photographer.<br>3. Kamera.<br>4. Printer.<br>5. Ukuran Foto 4 R.<br>6. Bingkai Kertas<br>7. Background.<br>8. Accesoris<br>', 2000000, 6, 'Jam', '2014-06-01', '2014-12-19', 'Reguler', '20abec5a6c2e2aab99864ad9bd0d0266.jpg', 'Di Setujui', 0),
(14, 'Tshirt for Event', 4, 'Anda dapat membuat t-shirt dengan design keren dan cetakan sablon yang berkualitas di octopus design<br>bahan T-shirt pun 90% Cutton yang nyaman dan tidak mudah rusak.<br>Minimal : 50 T-Shirt<br>jika harga satuan : Rp. 100000<br>', 50000, 1, 'Pieces', '2014-09-01', '2014-12-19', 'Reguler', 'ff58df56c4585646c65deaa602bb4038.jpg', 'Di Setujui', 0),
(15, 'Photo Booth Simple', 11, 'Jadikan Photo Both sebagai sovenir pernikahan anda<br>Photo booth sudah termasuk:<br>1. alat kamera.<br>2. Photographer.<br>3. Kamera.<br>4. Printer.<br>5. Ukuran Foto 4 R.<br>6. Bingkai Kertas<br>7. Background.<br>8. Accesoris<br>										<br>', 1500000, 5, 'Jam', '2014-08-01', '2014-12-01', 'Promo', '9a19fae6d868cd92c4c2b299816f3067.jpg', 'Di Setujui', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_profil`
--

CREATE TABLE IF NOT EXISTS `mst_profil` (
  `id_profil` int(11) NOT NULL AUTO_INCREMENT,
  `deskripsi` text NOT NULL,
  `link_fb` varchar(100) DEFAULT NULL,
  `link_twitter` varchar(100) DEFAULT NULL,
  `link_ins` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `keterangan` varchar(30) NOT NULL,
  PRIMARY KEY (`id_profil`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `mst_profil`
--

INSERT INTO `mst_profil` (`id_profil`, `deskripsi`, `link_fb`, `link_twitter`, `link_ins`, `photo`, `keterangan`) VALUES
(1, '&nbsp;&nbsp;										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Welcome to Octopus Design and Photograph<br><br>&nbsp;&nbsp; Kami adalah perusahaan jasa dan design yang terpercaya dan memberikan pelayanan jasa serta produk yang memuaskan bagi pelanggan. octopus memiliki produk unggulan yang di kerjaan oleh para karyawan yang ahli di bidangya.<br>&nbsp;&nbsp; &nbsp;  Produk yang kami tawarkan diantaranya :<br>1. Photo Studio<br>2. Year Book.<br>3. Banner.<br>4. Cup Printing Art<br>6. Photo Booth<br>7. Photo Praweding<br>8. Design T-Shirt<br>9. Photo Book<br>10. Photo Event<br>', 'facebook.com/octopusdesg', 'twitter.com/octopusdesignphoto', 'instagram.com/octopusdesgn1', '09fdd8292ca311dc545b809521b572cb.jpg', 'profil'),
(3, '&nbsp;											&nbsp; &nbsp; &nbsp; &nbsp; Octopus Design and Photograph menyediakan aneka product yang kreatif dan harga yang terjangkau.kami juga menawarkan produk promo yang dapat di pesan secara online dengan batas penukaran kode promo yang di pesan sesuai dengan masa berlaku produk promo.sebelum melakukan pemesanan pengunjung harus membuat akun<br>', NULL, NULL, NULL, 'b8f4fdfe26246a45eb7a250db8798988.png', 'howtoorder');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mst_user`
--

CREATE TABLE IF NOT EXISTS `mst_user` (
  `nik` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `akses` varchar(50) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mst_user`
--

INSERT INTO `mst_user` (`nik`, `username`, `password`, `akses`, `status`) VALUES
(1, 'nilam', 'af003347e9ad13dcb79763e2f66339d5', 'Member', 'Aktif'),
(101, 'indah', 'f3385c508ce54d577fd205a1b2ecdfb7', 'Admin', 'Aktif'),
(10101, 'hanif', '72e74f574535bdc82cf4b99f8fc064e1', 'Pemilik', 'Aktif'),
(10233, 'salwa', 'af003347e9ad13dcb79763e2f66339d5', 'Karyawan Marketing', 'Aktif'),
(1001010, 'panji', 'd6b16b990a41b83f81a58d38ad7265f1', 'Karyawan Kreatif Design', 'Aktif');

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `mst_katalog`
--
ALTER TABLE `mst_katalog`
  ADD CONSTRAINT `fk_idk` FOREIGN KEY (`id_jenisproduk`) REFERENCES `mst_jenisproduk` (`id_jenisproduk`);

--
-- Ketidakleluasaan untuk tabel `mst_pemesanan`
--
ALTER TABLE `mst_pemesanan`
  ADD CONSTRAINT `fk_ip` FOREIGN KEY (`id_produk`) REFERENCES `mst_produk` (`id_produk`),
  ADD CONSTRAINT `fk_nm` FOREIGN KEY (`nik`) REFERENCES `mst_member` (`nik`);

--
-- Ketidakleluasaan untuk tabel `mst_produk`
--
ALTER TABLE `mst_produk`
  ADD CONSTRAINT `fk_ij` FOREIGN KEY (`id_jenisproduk`) REFERENCES `mst_jenisproduk` (`id_jenisproduk`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
