<div class="container">
		<div class="row">
			<div class="span12">
				<h1>How To Order</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<li  ><a href="<?php echo base_url(); ?>index.php/menuadmin/daftarpemesan">Daftar Pemesan</a></li>
								<li class="active"><a href="#">Persetujuan Pemesanan</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_persetujuanpemesanan" method="POST" enctype="multipart/form-data">
							<fieldset>
								
									<div>
										<br/>
									</div>
										<label class="control-label" for="input02">Id Pemesanan </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'id_pemesanan','readonly'=>'readonly','value'=>$hpemesan->id_pemesanan))?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Nik Pemesanan </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'nik','readonly'=>'readonly','value'=>$hpemesan->nik))?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Nama Pemesanan </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'nama_member','readonly'=>'readonly','value'=>$hpemesan->nama_member))?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Nama Produk </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'nama_produk','readonly'=>'readonly','value'=>$hpemesan->nama_produk))?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Harga Produk </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'harga_produk','readonly'=>'readonly','value'=>$hpemesan->harga_produk))?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Jumlah Produk </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'jumlah_produk','readonly'=>'readonly','value'=>$hpemesan->jumlah_produk))?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Nama Produk </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'nama_produk','readonly'=>'readonly','value'=>$hpemesan->nama_produk))?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Nama Produk </label>
									<div class="controls">
										<select name = "persetujuan" >
											<option value = "Diproses">Di Proses</option>
											<option value = "Disetujui">Di Setujui</option>
											<option value = "Ditolak">Di Tolak</option>
						
						
										</select>
									</div>
									<div>
										<br/>
									</div>
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>