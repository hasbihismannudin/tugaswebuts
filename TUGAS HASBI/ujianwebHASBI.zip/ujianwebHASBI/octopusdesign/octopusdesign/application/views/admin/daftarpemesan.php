<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Pemesanan</h1><br />
				<div class="row">
					<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->
					<!-- table, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<ul class="nav nav-tabs">
								<li  class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/katalog">Daftar Pemesan</a></li>
								
							</ul>
							
						</div><!-- basic tabs menu -->
						<h5>Daftar Pemesan</h5><br />
						<?php 
							if (empty ($hpemesan)){
								echo "Data Tidak Ada";
							}
							else{
						?>
							<table class="table table-striped table-bordered"><!-- table default style -->
								<thead>
									<th>No</th>
									<th>Id Pemesanan</th>
									<th>Nik Pemesan</th>
									<th>Nama Pemesan</th>
									<th>Nama Produk</th>
									<th>Harga Produk</th>
									
									<th>Jumlah Produk</th>
									<th>Total Harga</th>
									
									<th colspan="2">Aksi</th>
								</thead>
							<?php
				$no = 1;
				foreach ($hpemesan as $data):
				
				?>
				<tr>
				
					<td><?php echo $no; ?></td>
					<td><?php echo $data->id_pemesanan;?></td>
					<td><?php echo $data->nik;?></td>
					<td><?php echo $data->nama_member;?></td>
					<td><?php echo $data->nama_produk;?></td>
					<td><?php echo $data->harga_produk;?></td>
					<td><?php echo $data->jumlah_produk;?></td>
					<td><?php echo $data->total_harga;?></td>
					
					<td>
					<?php if($data->persetujuan == "Diproses"){ ?>
					<a href="<?php echo base_url(); ?>index.php/menuadmin/persetujuan_pemesanan/<?php echo $data->id_pemesanan;?>">Proses Persetujuan</a> |
					<?php
					}else{
					echo "Disetujui";
					}
					?>	<a href="<?php echo base_url(); ?>index.php/menuadmin/delete_pesanan/<?php echo $data->id_pemesanan;?>">Delete</a> |
				
					

					</td>
				</tr>		
							
							<?php 
							$no++;
							endforeach;
							}

							?>
							</table><!-- table default style -->
					</div>
					<!-- table, content, etc -->
				</div>
				<div class="row">
				</div>
			</div>
		</div>