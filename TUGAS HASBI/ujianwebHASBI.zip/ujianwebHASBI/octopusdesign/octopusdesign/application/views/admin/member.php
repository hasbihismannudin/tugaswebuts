<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Daftar Member</h1><br />
				<div class="row">
					<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->
					<!-- table, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<ul class="nav nav-tabs">
								<li  class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/member">Daftar Member</a></li>
								
							
							</ul>
							
						</div><!-- basic tabs menu -->
						<h5>Daftar Member</h5><br />
						<?php 
							if (empty ($hmember)){
								echo "Data Tidak Ada";
							}
							else{
						?>
							<table class="table table-striped table-bordered"><!-- table default style -->
								<thead>
									<th>No</th>
									<th>Nik</th>
									<th>Nama Member</th>
									<th>Alamat </th>
									
									<th colspan="2">Aksi</th>
								</thead>
							<?php
				$no = 1;
				foreach ($hmember as $data):
				
				?>
				<tr>
				
					<td><?php echo $no; ?></td>
					<td><?php echo $data->nik;?></td>
					<td><?php echo $data->nama_member;?></td>
					<td><?php echo $data->alamat_member;?></td>
					<td><a href="<?php echo base_url(); ?>index.php/menuadmin/view_member/<?php echo $data->nik;?>">View</a> |
					
					</td>
				</tr>		
							
							<?php 
							$no++;
							endforeach;
							}

							?>
							</table><!-- table default style -->
					</div>
					<!-- table, content, etc -->
				</div>
				<div class="row">
				</div>
			</div>
		</div>