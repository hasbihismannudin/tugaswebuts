<div class="container">
		<div class="row">
			<div class="span12">
			<?php
		
		
			?>
				<h1>Daftar Karyawan</h1><br />
				<div class="row">
					<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->
					<!-- table, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<ul class="nav nav-tabs">
								<li  class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/karyawan">Daftar Karyawan</a></li>
								<?php 
								if($this->session->userdata('akses') == "Admin"| $this->session->userdata('akses') == "Pemilik" ){
								?>
								<li><a href="<?php echo base_url(); ?>index.php/menuadmin/tambahkaryawan">Tambah Karyawan</a></li>
								<?php
									}
								?>
								<li ><a href="<?php echo base_url(); ?>index.php/menuadmin/data_diri">Data diri</a></li>
							</ul>
							
						</div><!-- basic tabs menu -->
						<h5>Daftar Karyawan, diurutkan berdasarkan data dimutahirkan.</h5><br />
						<?php 
							if (empty ($hkaryawan)){
								echo "Data Tidak Ada";
							}
							else{
						?>
							<table class="table table-striped table-bordered"><!-- table default style -->
								<thead>
									<th>No</th>
									<th>Nik Karyawan</th>
									<th>Nama Karyawan</th>
									<th>Jabatan</th>
									
									<th colspan="2">Aksi</th>
								</thead>
							<?php
				$no = 1;
				foreach ($hkaryawan as $data):
				
				?>
				<tr>
					<td><?php echo $no; ?></td>
					<td><?php echo $data->nik;?></td>
					<td><?php echo $data->nama_karyawan;?></td>
					<td><?php echo $data->jabatan_karyawan;?></td>
					
					<td><?php if ($this->session->userdata('akses') == "Admin"| $this->session->userdata('akses') == "Pemilik"){ ;?> <a href="<?php echo base_url(); ?>index.php/menuadmin/update_karyawan/<?php echo $data->nik;?>">Update</a> |
						<a href="<?php echo base_url(); ?>index.php/menuadmin/delete_karyawan/<?php echo $data->nik;?>">Delete</a> | <?php };?>
						<a href="<?php echo base_url(); ?>index.php/menuadmin/viewkaryawan/<?php echo $data->nik;?>">View</a> |

					</td>
				</tr>		
							
							<?php 
							$no++;
							endforeach;
							}

							?>
							</table><!-- table default style -->
					</div>
					<!-- table, content, etc -->
				</div>
				<div class="row">
				</div>
			</div>
		</div>