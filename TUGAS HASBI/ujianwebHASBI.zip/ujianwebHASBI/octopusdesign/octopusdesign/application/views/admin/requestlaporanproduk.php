<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Request Laporan Produk</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								
								<li class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/requestlaporanproduk">Request Laporan Produk</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/laporanproduk" method="POST" enctype="multipart/form-data">
							<fieldset>
									
									<label class="control-label" for="input02">Nik Karyawan Marketing</label>
									<div class="controls">
									 <input type="text" name="nikmarketing" value="<?php echo $this->session->userdata('nik');?>"  readonly="readonly"/>
									</div>
									<div>
										<br/>
									</div>
									
									<label class="control-label" for="input02">Periode Dari </label>
									<div class="controls">
										
										<select name="tgl1">
										<?php
										for ($i=1; $i<=30; $i++) {
										$tgl = ($i<10) ? "0$i" : $i;
										echo "<option value='$tgl'>$tgl</option>";	
										}
										?>
										</select>
										<select name="bln1">
										
											<option value="01">Januari</option>
											<option value="02">Februari</option>
											<option value="03">Maret</option>
											<option value="04">April</option>
											<option value="05">Mei</option>
											<option value="06">Juni</option>
											<option value="07">Juli</option>
											<option value="08">Agustus</option>
											<option value="09">September</option>
											<option value="10">Oktober</option>
											<option value="11">November</option>
											<option value="12">Desember</option>
										</select>&nbsp;&nbsp;<br /><br />
										<select name="thn1">
										<?php
									
											for($thn = 2000;$thn<=2020;$thn++){
										?>
											<option value="<?php echo $thn;?>"><?php echo $thn;?></option>
											
										<?php
										
										}
										?>
										</select>
									</div>
									<div>
										<br/>
									</div>
									
									
									<label class="control-label" for="input02">Periode Sampai </label>
									<div class="controls">
										
										<select name="tgl2">
										<?php
										for ($i=1; $i<=30; $i++) {
										$tgl = ($i<10) ? "0$i" : $i;
										echo "<option value='$tgl'>$tgl</option>";	
										}
										?>
										</select>
										<select name="bln2">
											
											<option value="01">Januari</option>
											<option value="02">Februari</option>
											<option value="03">Maret</option>
											<option value="04">April</option>
											<option value="05">Mei</option>
											<option value="06">Juni</option>
											<option value="07">Juli</option>
											<option value="08">Agustus</option>
											<option value="09">September</option>
											<option value="10">Oktober</option>
											<option value="11">November</option>
											<option value="12">Desember</option>
										</select>&nbsp;&nbsp;<br /><br />
										<select name="thn2">
										<?php
									
											for($thn = 2000;$thn<=2020;$thn++){
										?>
											<option value="<?php echo $thn;?>"><?php echo $thn;?></option>
											
										<?php
									
										}
										?>
										</select>
									</div>
									<div>
										<br/>
									</div>
									
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Buat laporan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>