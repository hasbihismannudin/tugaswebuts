<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Profil</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
							<li  ><a href="#">View Karyawan</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<fieldset>
							<div id = "style">
							<b>
								<table >
								
									<tr>
										<td width = "200" height = "30">Nik Karyawan</td>
										<td  height = "30"><?php echo $hkaryawan->nik ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Nama Karyawan</td>
										<td height = "30"><?php echo $hkaryawan->nama_karyawan ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Tanggal Lahir Karyawan</td>
										<td  height = "30"><?php echo $hkaryawan->tgl_lahir ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Alamat Karyawan</td>
										<td height = "30"><?php echo $hkaryawan->alamat_karyawan ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Jenis Kelamin Karyawan</td>
										<td  height = "30"><?php echo $hkaryawan->jk_karyawan ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Email Karyawan</td>
										<td height = "30"><?php echo $hkaryawan->email_karyawan ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Telephone Karyawan</td>
										<td  height = "30"><?php echo $hkaryawan->tlpn_karyawan ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Jabatan Karyawan</td>
										<td  height = "30"><?php echo $hkaryawan->jabatan_karyawan ;?></td>
									</tr>
									<tr>
										<td  width = "200" height = "30">Foto Karyawan</td>
										<td  height = "30"><img  width="220px"  src="<?php echo base_url(); ?>upload/karyawan/thumb/<?php echo$hkaryawan->photo_karyawan;?>" alt=""></td>
									</tr>
									
									
									
									
									
								</table>
								</b>
								</div>
							</fieldset>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>