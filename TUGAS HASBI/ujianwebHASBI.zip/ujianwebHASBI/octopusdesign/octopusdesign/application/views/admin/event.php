<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Daftar Event</h1><br />
				<div class="row">
					<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->
					<!-- table, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<ul class="nav nav-tabs">
								<li  class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/event">Daftar Event</a></li>
								<li><a href="<?php echo base_url(); ?>index.php/menuadmin/tambahevent">Tambah Event</a></li>
							
							</ul>
							
						</div><!-- basic tabs menu -->
						<h5>Daftar Event</h5><br />
						<?php 
							if (empty ($hevent)){
								echo "Data Tidak Ada";
							}
							else{
						?>
							<table class="table table-striped table-bordered"><!-- table default style -->
								<thead>
									<th>No</th>
									<th>Id Event</th>
									<th>Judul Event</th>
									<th>Tanggal Event</th>
									
									<th colspan="2">Aksi</th>
								</thead>
							<?php
				$no = 1;
				foreach ($hevent as $data):
				
				?>
				<tr>
					<td><?php echo $no; ?></td>
					<td><?php echo $data->id_event;?></td>
					<td><?php echo $data->judul_event;?></td>
					<td><?php echo $data->tanggal_event;?></td>
					<td><a href="<?php echo base_url(); ?>index.php/menuadmin/updateevent/<?php echo $data->id_event;?>">Update</a> |
						<a href="<?php echo base_url(); ?>index.php/menuadmin/delete_event/<?php echo $data->id_event;?>">Delete</a> |
						<a href="<?php echo base_url(); ?>index.php/menuadmin/viewevent/<?php echo $data->id_event;?>">View</a> |

					</td>
				</tr>		
							
							<?php 
							$no++;
							endforeach;
							}

							?>
							</table><!-- table default style -->
					</div>
					<!-- table, content, etc -->
				</div>
				<div class="row">
				</div>
			</div>
		</div>