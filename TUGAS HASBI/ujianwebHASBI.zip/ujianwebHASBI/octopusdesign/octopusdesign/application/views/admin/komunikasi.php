<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Komunikasi</h1><br />
				<div class="row">
					<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->
					<!-- table, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<ul class="nav nav-tabs">
								<li  class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/komunikasi">komunikasi</a></li>
								
							
							</ul>
							
						</div><!-- basic tabs menu -->
						<h5>Daftar Komunikasi</h5><br />
						<?php 
							if (empty ($hkomunikasi)){
								echo "Data Tidak Ada";
							}
							else{
						?>
							<table class="table table-striped table-bordered"><!-- table default style -->
								<thead>
									<th>No</th>
									<th>From</th>
									<th>Email</th>
									<th>Tanggal</th>
									
									<th>Isi Pesan</th>
									<th>Status</th>
							
									<th colspan="2">Aksi</th>
								</thead>
							<?php
				$no = 1;
				foreach ($hkomunikasi as $data):
				
				?>
				<tr>
					<td><?php echo $no; ?></td>
					<td><?php echo $data->name;?></td>
					<td><?php echo $data->email_dari;?></td>
					<td><?php echo $data->tgl_komunikasi;?></td>
					<td><?php echo $data->isi;?></td>
					<td><?php echo $data->status;?></td>
					<td>
					<?php
					if($data->status == "Menerima"){
					?>
					<a href="<?php echo base_url(); ?>index.php/menuadmin/balaskomunikasi/<?php echo $data->id_komunikasi;?>">Reply</a> |
					<?php
					}?>
					<a href="<?php echo base_url(); ?>index.php/menuadmin/delete_komunikasi/<?php echo $data->id_komunikasi;?>">delete</a> |
				
					</td>
				</tr>		
							
							<?php 
							$no++;
							endforeach;
							}

							?>
							</table><!-- table default style -->
					</div>
					<!-- table, content, etc -->
				</div>
				<div class="row">
				</div>
			</div>
		</div>