<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Tambah Jenis Produk</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<li  ><a href="<?php echo base_url(); ?>index.php/menuadmin/jenisproduk">Jenis Produk</a></li>
								<li class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/tambahjenisproduk">Tambah Jenis Produk</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_tambahjenisproduk" method="POST" enctype="multipart/form-data">
							<fieldset>
								
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Nama Jenis Produk </label>
									<div class="controls">
									<?php echo form_input('nama_jenisproduk')?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Keterangan </label>
									<div class="controls">
									<?php echo form_input('keterangan')?>
									</div>
									<div>
										<br/>
									</div>
									
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>