<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Persetujuan Produk</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
							
								<li class="active"><a href="#">Persetujuan</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_persetujuan" method="POST" enctype="multipart/form-data">
							<fieldset>
								<label class="control-label" for="input02">Id Produk </label>
									<div class="controls">
									<?php echo form_input(array('name'=>'id_produk','readonly'=>'readonly','value'=>$hproduk->id_produk))?>
									</div>
									<div>
										<br/>
									</div>
								<label class="control-label" for="input02">Nama Produk</label>
									<div class="controls">
									<?php echo form_input(array('name'=>'nama_produk','readonly'=>'readonly','value'=>$hproduk->nama_produk))?>
									
									</div>
									<div>
										<br/>
									</div>
								
								<label class="control-label" for="input02">Kategori</label>
									<div class="controls">
										<select name ="kategori">
											<?php
											if($hproduk->kategori == "Reguler"){
											?>
											<option value = "Reguler" select = "selected">Reguler</option>
											<option value = "Promo">Promo</option>
											<?php
											}else{
											
											?>
											<option value = "Reguler" select = "selected">Reguler</option>
											<option value = "Promo">Promo</option>
									    	
											<?php
												}
											?>
											</select>
									</div>
									
									<div>
										<br/>
									</div>
								
								
											<!-- default input text -->
								<label class="control-label" for="input02">Persetujuan</label>
									<div class="controls">
										<select name ="persetujuan">
											<?php
											if($hproduk->persetujuan == "Di Proses"){
											?>
											<option value = "Di Proses" >Di Proses</option>
											<option value = "Di Setujui">Di Setujui</option>
											<option value = "Di Tolak">Di Tolak</option>
											<?php
											}else if($hproduk->persetujuan == "Di Setujui"){
											?>
											
											<option value = "Di Setujui" >Di Setujui</option>
											<option value = "Di Proses" >Di Proses</option>
											<option value = "Di Tolak" >Di Tolak</option>
											<?php
											}else{
											
											?>
											<option value = "Di Tolak" >Di Tolak</option>
											<option value = "Di Setujui" >Di Setujui</option>
											<option value = "Di Proses" >Di Proses</option>
											
									    	
											<?php
												}
											?>
											</select>
									
									</div>
									<div>
										<br/>
									</div>
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>