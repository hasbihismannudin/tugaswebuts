<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Daftar Produk</h1><br />
				<div class="row">
					<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->
					<!-- table, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
						
							<ul class="nav nav-tabs">
									
								<li class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/produk">Daftar Produk</a></li>
								<li ><a href="<?php echo base_url(); ?>index.php/menuadmin/tambahproduk">Tambah Produk</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<h5>Daftar Produk, diurutkan berdasarkan data dimutahirkan.</h5><br />
					
							<table class="table table-striped table-bordered"><!-- table default style -->
								<thead>
									<th>No</th>
									<th>Id Produk</th>
									<th>Nama Produk</th>
									<th>Gambar</th>
									<th>Deskripsi</th>
									<th>Kategori</th>
									<th colspan="2">Aksi</th>
								</thead>
								<tr>
								<?php 
							if (empty ($hproduk)){
								echo "Data Tidak Ada";
							}
							else{
						?>
								<?php $no=1; 
									foreach ($hproduk as $produk):
								?>
									<td><?php echo $no; ?></td>
									<td><?php echo $produk->id_produk; ?></td>
									<td><?php echo $produk->nama_produk; ?></td>
									<td>
										<!--mulai div modal untuk tampilkan gambar penuh -->
										<div id="example<?php echo $no;?>" class="modal hide fade in"  > 
											
										<div class="modal-header">  
											<a class="close" data-dismiss="modal">x</a>  
											<h4>Gambar lebih besar</h4>  
										</div>  
										<div class="modal-body">  
											<img src="<?php echo base_url(); ?>upload/produk/<?php echo $produk->photo; ?>" alt="">          
										</div>  
										<div class="modal-footer">    
											<a href="#" class="btn" data-dismiss="modal">Close</a>  
										</div> 
										</div>
										<!--end div modal untuk tampilkan gambar penuh -->
										<a href="">
											<img  width="220px" src="<?php echo base_url(); ?>upload/produk/<?php echo$produk->photo;?>" alt="">
										<!-- panggil modal -->
										<p><a data-toggle="modal" href="#example<?php echo $no;?>" class="btn btn-primary btn-small">Lebih besar</a></p>  
										<!-- end panggil modal -->
										</a>
									</td>
									<td>
										<!--mulai div modal untuk tampilkan gambar penuh -->
										<div id="example1<?php echo $no;?>" class="modal hide fade in"  > 
											
										<div class="modal-header">  
											<a class="close" data-dismiss="modal">x</a>  
											<h4>Deksripsi Selengkapnya</h4>  
										</div>  
										<div class="modal-body">  
											<?php echo $produk->deskripsi; ?>
										</div>  
										<div class="modal-footer">    
											<a href="#" class="btn" data-dismiss="modal">Close</a>  
										</div> 
										</div>
										<!--end div modal untuk tampilkan gambar penuh -->
										<?php echo substr(($produk->persetujuan),0,50); ?>...     	
										<!-- panggil modal -->
										<p><a data-toggle="modal" href="#example1<?php echo $no;?>" class="btn btn-primary btn-small">Selengkapnya</a></p>  
										<!-- end panggil modal -->
									</td>
									<td><?php echo ucwords($produk->kategori); ?></td>
									<td border="0">
										<?php if ($this->session->userdata('akses') == "Pemilik"){ ;?>
										<a title="Edit Produk Produk" href="<?php echo base_url(); ?>index.php/menuadmin/persetujuan/<?php echo $produk->id_produk; ?>">
											<i class="icon-edit"></i> Edit
										<?php
											}else{
										?>
										<a title="Edit Produk Produk" href="<?php echo base_url(); ?>index.php/menuadmin/updateproduk/<?php echo $produk->id_produk; ?>">
											<i class="icon-edit"></i> Edit
										<?php
											}
										?>
										</a> | <a href="#" onClick="if(confirm('Anda yakin HAPUS data ini? ')){document.location='<?php echo base_url(); ?>index.php/menuadmin/delete_produk/<?php echo $produk->id_produk; ?>'}" title="Hapus Produk" >
											<i class="icon-trash"></i> Hapus
										</a>
									</td>
								</tr>
							<?php 
								$no++;
									endforeach; 
							?>
								<?php
		}
		?>
							</table><!-- table default style -->
							
					</div>
					
					<!-- table, content, etc -->
				</div>
				<div class="row">
				</div>
			</div>
		</div>
	