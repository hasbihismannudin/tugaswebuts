 <!-- sidebar menu -->
<div class="span2">
	<ul class="nav nav-list"><!-- menu with icon -->
		<li class="nav-header">
			Menu Administrator Website
		</li>
		
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/karyawan">
				<i class="icon-list-alt"></i> Karyawan
			</a>
		</li>
		<?php if($this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin"){ 
		?>	
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/jenisproduk">
				<i class="icon-list-alt"></i> Jenis Produk
			</a>
		</li>
							
		<?php 
			}
		?>
		<?php if($this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" |
			$this->session->userdata('akses') == "Pemilik"){ 
		?>	
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/produk">
				<i class="icon-list-alt"></i> Produk
			</a>
		</li>
		<?php 
			}
		?>
		<?php if($this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){ 
		?>	
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/katalog">
				<i class="icon-list-alt"></i> Katalog
			</a>
		</li>
		<?php 
			}
		?>
		<?php if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){ 
		?>		
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/profil">
				<i class="icon-globe"></i> Profil
			</a>
		</li>
		<?php 
			}
		?>
		<?php if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){ 
		?>
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/event">
				<i class="icon-globe"></i> Event
			</a>
		</li>
		<?php 
			}
		?>
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/komunikasi">
				<i class="icon-globe"></i> komunikasi
			</a>
		</li>
			<?php if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){ 
		?>
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/member">
				<i class="icon-globe"></i>Member
			</a>
		</li>
		<?php 
			}
		?>
	
		<?php if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){ 
		?>
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/requestlaporanproduk">
				<i class="icon-globe"></i>Laporan Produk
			</a>
		</li>
		<?php 
			}
		?>
		<?php if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){ 
		?>
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/requestlaporanpromosi">
				<i class="icon-globe"></i>Laporan Promosi
			</a>
		</li>
		<?php 
			}
		?>
		<?php if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){ 
		?>
		<li>
			<a href="<?php echo base_url(); ?>index.php/menuadmin/daftarpemesan">
				<i class="icon-globe"></i>Pemesanan
			</a>
		</li>
		<?php 
			}
		?>
		<li>
			<a href="<?php echo base_url(); ?>index.php/auth/logout">
				<i class="icon-globe"></i> Log Out
			</a>
		</li>
							
								
							
	</ul><!-- end menu with icon -->	
<hr />
</div>
					<!-- sidebar menu -->