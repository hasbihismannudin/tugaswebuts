<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Balas Komunikasi</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<li class="active" ><a href="<?php echo base_url(); ?>index.php/menuadmin/balaskomunikasi">Balas Pesan Komunikasi</a></li>
								
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_pesankomunikasi" method="POST" enctype="multipart/form-data">
							<fieldset>
								<?php if(form_error('deskripsi') == FALSE) { ?>
								<div class="control-group"><!-- default input text -->
								<?php }else{ ?>
								<div class="control-group warning"><!-- warning -->
								<?php } ?>
									
										<!-- start ini untuk wysi rich text editor -->
											<label class="control-label" for="input02">Id Komunikasi</label>
									<div class="controls">
								
										<input type="text"  value="<?php echo $hkomunikasi->id_komunikasi;?>" name="id_komunikasi" readonly="readonly"  />
									</div>
									<div>
										<br/>
									</div>
										<label class="control-label" for="input02">Email Dari Pengunjung</label>
									<div class="controls">
								
										<input type="text"  value="<?php echo $hkomunikasi->email_dari;?>" name="email_kepada" readonly="readonly"  />
									</div>
									<div>
										<br/>
									</div>
										<label class="control-label" for="input02">Pesan </label>
									<div class="controls">
									<textarea name="pesanpengunjung" style="width: 440px; height:340px; " cols="20" id="some-textarea" readonly="readonly">
									<?php echo $hkomunikasi->tgl_komunikasi;?> -
									
									<?php echo $hkomunikasi->isi;?>
									
									</textarea>
									
									</div>
									<div>
										<br/>
									</div>
											<label class="control-label" for="input02">Balas Pesan </label>
									<div class="controls">
											
										<textarea name="deskripsi" style="width: 440px; height:340px; " cols="20" id="some-textarea"></textarea>
										<!-- end ini untuk wysi rich text editor -->	
										
									</div>
									<div>
										<br/>
									</div>
															</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Kirim</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>