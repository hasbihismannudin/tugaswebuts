<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Profil</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
							View Katalog
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<fieldset>
							<div id = "style">
							<b>
								<table >
								
									<tr>
										<td width = "150" height = "30">Id Katalog</td>
										<td width = "150" height = "30"><?php echo $hkatalog->id_katalog ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Nama Katalog</td>
										<td width = "150" height = "30"><?php echo $hkatalog->nama_katalog ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Link Katalog</td>
										<td width = "150" height = "30"><?php echo $hkatalog->link_katalog ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Tanggal Katalog</td>
										<td width = "150" height = "30"><?php echo $hkatalog->tanggal_katalog ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Nama Jenis Produk</td>
										<td width = "150" height = "30"><?php echo $hkatalog->nama_jenisproduk ;?></td>
									</tr>
									
									
									
									
								</table>
								</b>
								</div>
							</fieldset>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>