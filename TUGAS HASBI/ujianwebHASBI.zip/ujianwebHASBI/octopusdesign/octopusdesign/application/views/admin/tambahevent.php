<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Tambah Event</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<li  ><a href="<?php echo base_url(); ?>index.php/menuadmin/event">Daftar Event</a></li>
								<li class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/tambahevent">Tambah Event</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_tambahevent" method="POST" enctype="multipart/form-data">
							<fieldset>
								<?php if(form_error('deskripsi') == FALSE) { ?>
								<div class="control-group"><!-- default input text -->
								<?php }else{ ?>
								<div class="control-group warning"><!-- warning -->
								<?php } ?>
								<label class="control-label" for="input02">Judul Event </label>
									<div class="controls">
									<?php echo form_input('judul_event')?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Isi Event</label>
									<div class="controls">
										<!-- start ini untuk wysi rich text editor -->
										
										<textarea name="isi_event" style="width: 440px; height:340px; " cols="20" id="some-textarea"></textarea>
										<!-- end ini untuk wysi rich text editor -->	
										<span class="help-inline"><?php echo form_error('isi_event'); ?></span>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Tanggal Event</label>
									<div class="controls">
											<select name="tgl1">
										<?php
										for ($i=1; $i<=30; $i++) {
										$tgl = ($i<10) ? "0$i" : $i;
										echo "<option value='$tgl'>$tgl</option>";	
										}
										?>
										</select>
										<select name="bln1">
										
											<option value="01">Januari</option>
											<option value="02">Februari</option>
											<option value="03">Maret</option>
											<option value="04">April</option>
											<option value="05">Mei</option>
											<option value="06">Juni</option>
											<option value="07">Juli</option>
											<option value="08">Agustus</option>
											<option value="09">September</option>
											<option value="10">Oktober</option>
											<option value="11">November</option>
											<option value="12">Desember</option>
										</select>&nbsp;&nbsp;<br /><br />
										<select name="thn1">
										<?php
									
											for($thn = 2000;$thn<=2020;$thn++){
										?>
											<option value="<?php echo $thn;?>"><?php echo $thn;?></option>
											
										<?php
										
										}
										?>
										</select>
									</div>
									<div>
										<br/>
									</div>
									
									<label class="control-label" for="input02">Upload Photo </label>
									<div class="controls">
										<div class="alert alert-info">  
											<a class="close" data-dismiss="alert">x</a>  
											<strong>Info! </strong><br/>
											Gambar optimal pada resolusi 800x400 px<br/>
											Ukuran Maksimum file 1 MB, (disarankan ukuran dibawah 100kb)<br/>
											File yang diizinkan untuk upload .jpg, .jpeg, .png, .gif
										</div>
										<input type="file" class="input" id="input01" name="photo_event">
										<span class="help-inline"></span>
									
									</div><!-- default input text -->
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>