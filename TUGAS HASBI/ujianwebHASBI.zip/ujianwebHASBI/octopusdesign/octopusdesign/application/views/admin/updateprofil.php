<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Profil</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<li class="active" ><a href="<?php echo base_url(); ?>index.php/menuadmin/profil">Profil</a></li>
								<li ><a href="<?php echo base_url(); ?>index.php/menuadmin/howtoorder">How To Order</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_updateprofil" method="POST" enctype="multipart/form-data">
							<fieldset>
								<?php if(form_error('deskripsi') == FALSE) { ?>
								<div class="control-group"><!-- default input text -->
								<?php }else{ ?>
								<div class="control-group warning"><!-- warning -->
								<?php } ?>
									<label class="control-label" for="input02">Deksripsi </label>
									<div class="controls">
										<!-- start ini untuk wysi rich text editor -->
										
										<textarea name="deskripsi" style="width: 440px; height:340px; " cols="20" id="some-textarea">
										<?php echo $hprofil->deskripsi ;?>
										</textarea>
										<!-- end ini untuk wysi rich text editor -->	
										<span class="help-inline"><?php echo form_error('deskripsi'); ?></span>
									</div>
									<div>
										<br/>
									</div>
									
									<label class="control-label" for="input02">Link Facebook </label>
									<div class="controls">
									<?php echo form_input('link_fb',$hprofil->link_fb);?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Link Twitter </label>
									<div class="controls">
									<?php echo form_input('link_twitter',$hprofil->link_twitter);?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Link Instagram </label>
									<div class="controls">
									<?php echo form_input('link_ins',$hprofil->link_ins);?>
									</div>
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Upload Photo </label>
									<div class="controls">
										<div class="alert alert-info">  
											<a class="close" data-dismiss="alert">x</a>  
											<strong>Info! </strong><br/>
											Gambar optimal pada resolusi 800x400 px<br/>
											Ukuran Maksimum file 1 MB, (disarankan ukuran dibawah 100kb)<br/>
											File yang diizinkan untuk upload .jpg, .jpeg, .png, .gif
										</div>
										<input type="file" class="input" id="input01" name="photo_profil">
										 <span class="help-inline">File Sebelumnya : <input type = "text" name="gambar" value = "<?php echo $hprofil->photo; ?>" >
										</span>
									
									</div><!-- default input text -->
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>