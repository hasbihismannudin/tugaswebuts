
    
		<hr />
		<div class="row">
			<div class="span12">
			<footer>
			<p>&copy; Admin Template 2014.</p>
			</footer>
			</div>
		</div><br />
		
    </div> <!-- /container -->

    <!-- Le javascript
   
   ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>assets/admin/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-transition.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-alert.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-modal.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-dropdown.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-tab.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-tooltip.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-popover.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-button.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-collapse.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-carousel.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-typeahead.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#tultip').tooltip('hide');
			//$('#form-login').css('margin-left', ($('.row-fluid').width()-$('#form-login').width())/2+"px");
		});
	</script>
	<!-- table fixed header -->
	<script src="<?php echo base_url(); ?>assets/admin/js/table-fixed-header.js"></script>
	<script language="javascript" type="text/javascript" >
			$('.table-fixed-header').fixedHeader();
	</script>
	<!-- end table fixed header -->
	<!-- wysihtml5 -->
	<script src="<?php echo base_url(); ?>assets/admin/js/wysihtml5-0.3.0.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-wysihtml5.js"></script>	
	<script type="text/javascript">
		$('#some-textarea').wysihtml5();
	</script>
	<!-- end wysihtml5 -- >
  </body>
</html>
