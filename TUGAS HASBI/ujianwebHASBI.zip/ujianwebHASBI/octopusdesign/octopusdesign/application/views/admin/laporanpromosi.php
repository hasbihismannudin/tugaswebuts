<?php
/*
*
* @author M.Fadli Prathama (09081003031)
* email : m.fadliprathama@gmail.com
*
*/

/* setting zona waktu */
$this->load->library('fpdf');
date_default_timezone_set('Asia/Jakarta');
$this->fpdf->FPDF("L","cm","A4");

// kita set marginnya dimulai dari kiri, atas, kanan. jika tidak diset, defaultnya 1 cm
$this->fpdf->SetMargins(1,1,1);
/* AliasNbPages() merupakan fungsi untuk menampilkan total halaman
di footer, nanti kita akan membuat page number dengan format : number page / total page
*/
$this->fpdf->AliasNbPages();

// AddPage merupakan fungsi untuk membuat halaman baru
$this->fpdf->AddPage();

// Setting Font : String Family, String Style, Font size
$this->fpdf->SetFont('Times','B',12);

$this->fpdf->Cell(30,0.7,'Laporan Promosi Jasa Octopus Design and Photograph Pondok Gede Jawa Barat',0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Cell(30,0.7,'Periode '.date('d-M-Y',strtotime($dari)).' Hingga '.date('d-M-Y',strtotime($sampai)),0,'C','C');
$this->fpdf->Line(1,3.5,30,3.5);

$this->fpdf->SetFont('Times','B',10);
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Cell(1 , 1, 'No' , 1, 'LR', 'C');
$this->fpdf->Cell(1 , 1, 'Id' , 1, 'C', 'C');
$this->fpdf->Cell(5 , 1, 'Nama' , 1, 'C', 'C');
$this->fpdf->Cell(5 , 1, 'Jenis' , 1, 'C', 'C');
$this->fpdf->Cell(2 , 1, 'Satuan' , 1, 'C', 'C');
$this->fpdf->Cell(2 , 1, 'Harga' , 1, 'C', 'C');
$this->fpdf->Cell(3 , 1, 'Awal Berlaku' , 1, 'C', 'C');
$this->fpdf->Cell(3 , 1, 'Akhir Berlaku' , 1, 'C', 'C');
$this->fpdf->Cell(2 , 1, 'Kategori' , 1, 'C', 'C');
$this->fpdf->Cell(2 , 1, 'Pembaca' , 1, 'C', 'C');
$this->fpdf->Cell(2 , 1, 'Pemesan' , 1, 'C', 'C');
$no = 1;
$this->fpdf->Ln();
if (empty ($hpromosi)){

$this->fpdf->Cell(1 , 1,'Data Tidak Ada', 1, 'LR', 'C');
}
else{
		$this->fpdf->SetFont('Times','',10);				
foreach($hpromosi as $produk):


$this->fpdf->Cell(1 , 1,$no, 1, 'LR', 'C');
$this->fpdf->Cell(1 , 1, $produk->id_produk ,1, 'LR', 'L');
$this->fpdf->Cell(5 , 1, $produk->nama_produk ,1, 'LR', 'L');
$this->fpdf->Cell(5 , 1, $produk->nama_jenisproduk ,1, 'LR', 'L');
$this->fpdf->Cell(2 , 1, $produk->satuan_produk ,1, 'LR', 'L');
$this->fpdf->Cell(2 , 1, $produk->harga_produk ,1, 'LR', 'L');
$this->fpdf->Cell(3 , 1, $produk->dari_tanggal ,1, 'LR', 'L');
$this->fpdf->Cell(3 , 1, $produk->sampai_tanggal ,1, 'LR', 'L');
$this->fpdf->Cell(2 , 1, $produk->kategori ,1, 'LR', 'L');
$this->fpdf->Cell(2 , 1, $produk->jumlah_show ,1, 'LR', 'L');
$this->fpdf->Cell(2 , 1, $produk->jumlah_pesanan ,1, 'LR', 'L');

$no++;
$this->fpdf->Ln();
endforeach;
}


$this->fpdf->SetFont('Times','B',12);
$this->fpdf->Cell(5,0.7,'Pondok Gede, '.$datenow,0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Cell(10,0.7,'Menyetujui,',0,'C','C');

$this->fpdf->Cell(20,0.7,'Disusun Oleh',0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Cell(10,0.7,'Pemilik',0,'C','C');

$this->fpdf->Cell(20,0.7,'Karyawan Marketing,',0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Cell(10,0.7,$hpemilik->nama_karyawan,0,'C','C');
$this->fpdf->Cell(20,0.7,$hmarketing->nama_karyawan,0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Cell(10,0.7,'( Nik : '.$hpemilik->nik.')',0,'C','C');
$this->fpdf->Cell(20,0.7,'( Nik : '.$hmarketing->nik.')',0,'C','C');
$this->fpdf->Output("laporan_seleksi_calok_atm.pdf","I");
?>