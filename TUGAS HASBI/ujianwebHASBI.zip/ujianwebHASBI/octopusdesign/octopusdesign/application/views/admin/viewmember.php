<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Profil</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
							<li  class="active"><a href="#">View Member</a></li>
								
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<fieldset>
							<div id = "style">
							<b>
								<table >
								
									<tr>
										<td width = "150" height = "30">Nik</td>
										<td width = "150" height = "30"><?php echo $hmember->nik ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Nama Lengkap</td>
										<td width = "150" height = "30"><?php echo $hmember->nama_member ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Tanggal Lahir</td>
										<td width = "150" height = "30"><?php echo $hmember->tgl_lahir ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Alamat Member</td>
										<td width = "150" height = "30"><?php echo $hmember->alamat_member ;?></td>
									</tr>
									
									<tr>
										<td width = "150" height = "30">Gender Member</td>
										<td width = "150" height = "30"><?php echo $hmember->jk_member ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Email Member</td>
										<td width = "150" height = "30"><?php echo $hmember->email_member ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Telephone Member</td>
										<td width = "150" height = "30"><?php echo $hmember->tlpn_member ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Nama Bank</td>
										<td width = "150" height = "30"><?php echo $hmember->nama_bank ;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Rekening Bank</td>
										<td width = "150" height = "30"><?php echo $hmember->rekening_bank;?></td>
									</tr>
									<tr>
										<td width = "150" height = "30">Foto Event</td>
										<td width = "150" height = "30"><img  width="220px" src="<?php echo base_url(); ?>upload/member/thumb/<?php echo$hmember->photo_member;?>" alt=""></td>
									</tr>
									
									
									
									
									
								</table>
								</b>
								</div>
							</fieldset>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>