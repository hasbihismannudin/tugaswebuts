<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Tambah Produk</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<li ><a href="<?php echo base_url(); ?>index.php/menuadmin/produk">Daftar Produk</a></li>
								<li class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/tambahproduk">Tambah Produk</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_tambahproduk" method="POST" enctype="multipart/form-data">
							<fieldset>
								<label class="control-label" for="input02">Nama Produk</label>
									<div class="controls">
									<?php echo form_input('nama_produk')?>
									</div>
									
								<label class="control-label" for="input02">Jenis Produk </label>
									<div class="controls">
										<select name = "id_jenisproduk" row = "30">
										<?php foreach($hjenisproduk as $data2):?>
										<option value= "<?php echo $data2->id_jenisproduk ;?>" size = "30"><?php echo $data2->nama_jenisproduk ;?></option>
										<?php endforeach;?>
							
										</select>
									</div>
										<label class="control-label" for="input02">Deksripsi </label>
									<div class="controls">
										<!-- start ini untuk wysi rich text editor -->
										
										<textarea name="deskripsi" style="width: 440px; height:340px; " cols="20" id="some-textarea"></textarea>
										<!-- end ini untuk wysi rich text editor -->	
										<span class="help-inline"><?php echo form_error('deskripsi'); ?></span>
									</div>
									
								<label class="control-label" for="input02">Harga Produk</label>
									<div class="controls">
										<?php echo form_input('harga_produk')?>
									</div>
									
								<label class="control-label" for="input02">Jumlah Produk</label>
									<div class="controls">
										<?php echo form_input('jumlah_produk')?>
									</div>
								<label class="control-label" for="input02">Satuan Produk</label>
									<div class="controls">
										<?php echo form_input('satuan_produk')?>
									</div>
									
								<label class="control-label" for="input02"> Tanggal Berlaku</label>
									<div class="controls">
											<select name="tgl1">
										<?php
										for ($i=1; $i<=30; $i++) {
										$tgl = ($i<10) ? "0$i" : $i;
										echo "<option value='$tgl'>$tgl</option>";	
										}
										?>
										</select>
										<select name="bln1">
										
											<option value="01">Januari</option>
											<option value="02">Februari</option>
											<option value="03">Maret</option>
											<option value="04">April</option>
											<option value="05">Mei</option>
											<option value="06">Juni</option>
											<option value="07">Juli</option>
											<option value="08">Agustus</option>
											<option value="09">September</option>
											<option value="10">Oktober</option>
											<option value="11">November</option>
											<option value="12">Desember</option>
										</select>&nbsp;&nbsp;<br /><br />
										<select name="thn1">
										<?php
									
											for($thn = 2000;$thn<=2020;$thn++){
										?>
											<option value="<?php echo $thn;?>"><?php echo $thn;?></option>
											
										<?php
										
										}
										?>
										</select>
									</div>
									
								<label class="control-label" for="input02">Sampai Tanggal</label>
									<div class="controls">
										<select name="tgl2">
										<?php
										for ($i=1; $i<=30; $i++) {
										$tgl = ($i<10) ? "0$i" : $i;
										echo "<option value='$tgl'>$tgl</option>";	
										}
										?>
										</select>
										<select name="bln2">
											
											<option value="01">Januari</option>
											<option value="02">Februari</option>
											<option value="03">Maret</option>
											<option value="04">April</option>
											<option value="05">Mei</option>
											<option value="06">Juni</option>
											<option value="07">Juli</option>
											<option value="08">Agustus</option>
											<option value="09">September</option>
											<option value="10">Oktober</option>
											<option value="11">November</option>
											<option value="12">Desember</option>
										</select>&nbsp;&nbsp;<br /><br />
										<select name="thn2">
										<?php
									
											for($thn = 2000;$thn<=2020;$thn++){
										?>
											<option value="<?php echo $thn;?>"><?php echo $thn;?></option>
											
										<?php
									
										}
										?>
										</select>
									</div>
								<label class="control-label" for="input02">Kategori</label>
									<div class="controls">
										<select name ="kategori">
											<option value = "Reguler">Reguler</option>
											<option value = "Promo">Promo</option>
											
										</select>
									
									</div>
									
									
								
								<label class="control-label" for="input02">Upload Photo </label>
									<div class="controls">
										<div class="alert alert-info">  
											<a class="close" data-dismiss="alert">x</a>  
											<strong>Info! </strong><br/>
											Gambar optimal pada resolusi 800x400 px<br/>
											Ukuran Maksimum file 1 MB, (disarankan ukuran dibawah 100kb)<br/>
											File yang diizinkan untuk upload .jpg, .jpeg, .png, .gif
										</div>
										<input type="file" class="input" id="input01" name="photo_produk">
										<span class="help-inline"></span>
									
									</div>
											<!-- default input text -->
								<label class="control-label" for="input02">Persetujuan</label>
									<div class="controls">
										<select name ="persetujuan">
											<option value = "Di Proses">Di Proses</option>
											
											
										</select>
									
									</div>
									
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>