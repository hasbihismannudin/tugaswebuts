<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Tambah Katalog</h1><br />
				<div class="row">
				<!--sidebar menu -->
					<?php echo $this->load->view('admin/sidebar'); ?>
					<!--end sidebar menu -->	
					<!-- form, content, etc -->
					<div class="span9">
						<div class=""><!-- basic tabs menu -->
							<ul class="nav nav-tabs">
								<li  ><a href="<?php echo base_url(); ?>index.php/menuadmin/katalog">Katalog</a></li>
								<li class="active"><a href="<?php echo base_url(); ?>index.php/menuadmin/tambahkatalog">Tambah Katalog</a></li>
							</ul>
						</div><!-- basic tabs menu -->
						<div class="well"><!-- div well & form -->
							<form class="form-horizontal" action="<?php echo base_url(); ?>index.php/menuadmin/submit_tambahkatalog" method="POST" enctype="multipart/form-data">
							<fieldset>
								
									<div>
										<br/>
									</div>
									<label class="control-label" for="input02">Nama  Katalog</label>
									<div class="controls">
									<?php echo form_input('nama_katalog')?>
									</div>
									<div>
										<br/>
									</div>
									
									<label class="control-label" for="input02">Link katalog </label>
									<div class="controls">
									<?php echo form_input('link_katalog')?>
									</div>
									<div>
										<br/>
									</div><label class="control-label" for="input02">Tanggal katalog </label>
									<div class="controls">
										<select name="tgl1">
										<?php
										for ($i=1; $i<=30; $i++) {
										$tgl = ($i<10) ? "0$i" : $i;
										echo "<option value='$tgl'>$tgl</option>";	
										}
										?>
										</select>
										<select name="bln1">
										
											<option value="01">Januari</option>
											<option value="02">Februari</option>
											<option value="03">Maret</option>
											<option value="04">April</option>
											<option value="05">Mei</option>
											<option value="06">Juni</option>
											<option value="07">Juli</option>
											<option value="08">Agustus</option>
											<option value="09">September</option>
											<option value="10">Oktober</option>
											<option value="11">November</option>
											<option value="12">Desember</option>
										</select>&nbsp;&nbsp;<br /><br />
										<select name="thn1">
										<?php
													
											for($thn = 1950;$thn<=2020;$thn++){
												
										?>
										
											<option value="<?php echo $thn;?>"><?php echo $thn;?></option>
											
										<?php
										
										}
										?>
										</select>
									</div>
									<div>
										<br/>
									</div>
									
									<label class="control-label" for="input02">Jenis Produk </label>
									<div class="controls">
										<select name = "id_jenisproduk" row = "30">
						<?php foreach($hjenisproduk as $data2):?>
							<option value= "<?php echo $data2->id_jenisproduk ;?>" size = "30"><?php echo $data2->nama_jenisproduk ;?></option>
						<?php endforeach;?>
							
						</select>
									</div>
									<div>
										<br/>
									</div>
							</fieldset>
							<div class="form-actions"><!-- button action -->
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
							</form>
						</div><!-- div without well class & form -->
						
					</div>
					<!-- form, content, etc -->
				</div>
			</div>
		</div>