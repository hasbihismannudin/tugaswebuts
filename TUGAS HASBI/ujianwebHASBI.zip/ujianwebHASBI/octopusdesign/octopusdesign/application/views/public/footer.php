<div class="main">
<!-- footer -->
	<footer>
		<div class="wrapper">
			<span class="left">
			 	Website template designed by <a href="http://www.templatemonster.com/" target="_blank" rel="nofollow">www.templatemonster.com</a><br>
			</span>
			<ul id="icons">
				<li><a href="<?php echo $hprofil->link_facebook;?>" class="normaltip" title="Facebook"><img src="<?php echo base_url();?>assets/public/images/icon1.png" alt=""></a></li>
				i><a href="#" class="normaltip" title="Twitter"><img src="<?php echo base_url();?>assets/public/images/icon4.png" alt=""></a></li>
				<li><a href="#" class="normaltip" title="Instagram"><img src="<?php echo base_url();?>assets/public/images/instagram.png" alt="" Width = "30" height = "30"></a></li>
				
			</ul>
		</div>
<!-- {%FOOTER_LINK} -->
	</footer>
<!-- / footer -->
</div>