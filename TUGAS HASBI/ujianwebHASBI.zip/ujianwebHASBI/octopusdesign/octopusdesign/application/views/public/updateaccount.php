<head>
	
        <title>Profil</title>
		</head>
<section id="content">
					<div class="wrapper">
						<h2>Update Your Account</h2>
						<div class="wrapper">	
							<figure class="left marg_right1"><img src="<?php echo base_url(); ?>assets/public/images/member.png" alt="" width="300" height="300"></figure>
						<form action="<?php echo base_url(); ?>index.php/publicdesign/submit_updateacount" method="post" enctype="multipart/form-data">
							<table align="center">
								<tr>
									<td width="200">
										Nomer Induk Keanggotaan
									</td>
									<td width="300" height="50px">
									
										<input type="text" name="nik" size="30" readonly="readonly" value="<?php echo $haccount->nik;?>" readonly="readonly"/>
										
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Nama Member
									</td>
									<td width="300" height="50px">
										<input type="text" name="nama_member" size="30" placeholder = "Nama Member"   value="<?php echo $haccount->     	                                        nama_member;?>"/>
										
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Username
									</td>
									<td width="300" height="50px">
										<input type="text" name="username" size="30" placeholder = "Username" value="<?php echo $haccount->     	                                        username;?>"  />
										
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Password
									</td>
									<td width="300" height="50px">
										<input type="password" name="password" size="30" value="<?php echo $haccount->password;?>" />
										
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Ganti Password
									</td>
									<td width="300" height="50px">
										<input type="password" name="password_baru" size="30" />
										
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Tanggal Lahir
									</td>
									<td width="300" height="50px">
									<?php list($thn2,$bln2,$tgl2) = explode("-",$haccount->tgl_lahir);
											
											?>
										<select name="tgl1" >
													<option value="<?php $tgl2;?>" selected><?php echo $tgl2;?></option>
										<?php
										for ($i=1; $i<=30; $i++) {
										$tgl = ($i<10) ? "0$i" : $i;
										echo "<option value='$tgl'>$tgl</option>";	
										}
										?>
										</select>
										<select name="bln1">
											<option value="<?php $bln2;?>" selected><?php echo $bln2;?></option>
											
											<option value="01">Januari</option>
											<option value="02">Februari</option>
											<option value="03">Maret</option>
											<option value="04">April</option>
											<option value="05">Mei</option>
											<option value="06">Juni</option>
											<option value="07">Juli</option>
											<option value="08">Agustus</option>
											<option value="09">September</option>
											<option value="10">Oktober</option>
											<option value="11">November</option>
											<option value="12">Desember</option>
										</select>&nbsp;&nbsp;<br /><br />
										<select name="thn1">
											<option value="<?php echo $thn2;?>" selected><?php echo $thn2;?></option>
										
										<?php
									
											for($thn = 1950;$thn<=2020;$thn++){
										?>
											<option value="<?php echo $thn;?>"><?php echo $thn;?></option>
											
										<?php
										$thn++;
										}
										?>
										</select>
										
									</td>
									
								</tr>
									<tr>
									<td width="200">
										<br />
										Alamat
									</td>
									<td width="300" >
									<br />
										<textarea name="alamat_member" rows="5" >
											<?php echo $haccount->alamat_member;?>
										</textarea>
									
									</td>
									
								</tr>
								<tr>
									<td width="200">
									<br />
										Gender 
									</td>
									<td width="300" height="50px">
											<br />
										<select name="jk_member"  required>
											<option value = "<?php echo $haccount->jk_member; ?>"><?php echo $haccount->jk_member; ?></option>
										
											<option value="Laki-Laki">Laki-Laki</option>
											<option value="Perempuan">Perempuan</option>
										
										</select>
										
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Email
									</td>
									<td width="300" height="50px">
										<input type="text" name="email_member" size="30" value="<?php echo $haccount->email_member; ?>"/>
										
									</td>
								</tr>
								<tr>
								<td width="200">
										Telephone
									</td>
									<td width="300" height="50px">
										<input type="text" name="tlpn_member" size="30"  value="<?php echo $haccount->tlpn_member; ?>"/>
										
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Foto
									</td>
									<td width="300" height="100px">
										<input type="file" name="photo_member" size="30" /><br /><br />
										<input type="text"  value="<?php echo $haccount->photo_member; ?>"/></td>
									</td>
									
								</tr>
								<tr>
									<td width="200">
										Nama Bank
									</td>
									<td width="300" height="50px">
										<input type="text" name="nama_bank" size="30" value="<?php echo $haccount->nama_bank; ?>"/>
										
									</td>
								</tr>
								<tr>
									<td width="200">
										Rekening Bank
									</td>
									<td width="300" height="50px">
										<input type="text" name="rekening_bank" size="30" value="<?php echo $haccount->rekening_bank; ?>"/>
										
									</td>
								</tr>
								<tr>
									<td width="200" >
									
									</td>
									<td width="300" height="50px">
										<input type="submit" value="Update" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" value="Cancel" /></center>
							
										
									</td>
								</tr>
							</table>	
							</form>
							
							</div>
				</section>
			</div>
		</div>
	</div>
</div>
<div class="body4">
	<div class="main">
		<section id="content2">
			<div class="line2 wrapper">
				<div class="wrapper">
					<article class="col1">
						<h2>The Office</h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php echo base_url();?>assets/public/images/home_office_icon.png" alt="" height = "100" width = "100"><br />
						<div class="pad">
							
							<p class="pad_bot2">
								<strong>
									Kantor Octopus Design and Photograph
									
								</strong>
							</p>
							
							<p>
							Provinsi&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;: Jawa Barat</br> 
							Kabupaten &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Pondok Gede </br>
							Alamat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: fdvnefkvje;kferlvk,rlv </br>
							No Telephone &nbsp;&nbsp;: 02188962081</br>
							Email &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <a href="#" class="link1">octopus0101@gmail.com </a>
							</p>
							
							
						</div>
					</article>
					<article class="col2 pad_left1">
						<h2>How To Order</h2>
						<div class="pad">
							
							<figure class="left marg_right1 marg_left1"><img src="<?php echo base_url(); ?>upload/profil/<?php echo $htoorder->photo;?>" alt="" width = "200" height = "200"></figure>
							<p>
								<?php
									echo $htoorder->deskripsi;
								?>
							</p>
						</div>
					</article>
				</div>
				
			</div>
		</section>
	</div>
</div>
<!-- / content -->
<div class="main">
<!-- footer -->
	<div class="main">
<!-- footer -->
	<footer>
		<div class="wrapper">
			<span class="left">
			 	Website template designed by <a href="http://www.templatemonster.com/" target="_blank" rel="nofollow">www.templatemonster.com</a><br>
			</span>
			<ul id="icons">
				<li><a href="../../../../<?php echo $hprofil->link_fb;?>" class="normaltip" title="Facebook" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon1.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_twitter;?>" class="normaltip" title="Twitter" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon4.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_ins;?>" class="normaltip" title="Instagram" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/instagram.png" alt="" Width = "30" height = "30"></a></li>
				
			</ul>
		</div>
<!-- {%FOOTER_LINK} -->
	</footer>
<!-- / footer -->
</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>