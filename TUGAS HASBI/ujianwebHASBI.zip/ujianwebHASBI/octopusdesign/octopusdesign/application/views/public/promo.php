<!DOCTYPE html>
<html lang="en">
    <head>
	
        <title>Promo</title>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
        <meta name="description" content="Responsive Image Gallery with jQuery" />
        <meta name="keywords" content="jquery, carousel, image gallery, slider, responsive, flexible, fluid, resize, css3" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico"> 
       <link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/style3.css" type="text/css" media="all">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/reset2.css" type="text/css" media="all">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/elastislide.css" type="text/css" media="all">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/demo.css" type="text/css" media="all">
     
		<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow&v1' rel='stylesheet' type='text/css' />
		<link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css' />
		<noscript>
			<style>
				.es-carousel ul{
					display:block;
				}
			</style>
		</noscript>
		<script id="img-wrapper-tmpl" type="text/x-jquery-tmpl">	
			<div class="rg-image-wrapper">
				{{if itemsCount > 1}}
					<div class="rg-image-nav">
						<a href="#" class="rg-image-nav-prev">Previous Image</a>
						<a href="#" class="rg-image-nav-next">Next Image</a>
					</div>
				{{/if}}
				<div class="rg-image"></div>
				<div class="rg-loading"></div>
				<div class="rg-caption-wrapper">
					<div class="rg-caption" style="display:none;">
						<p></p>
					</div>
				</div>
			</div>
		</script>
    </head>
    <body>
	<h1>Our Promotion</h1>
	<br/>
		<div class="container">
			
			
			<div class="content">
			
				<div id="rg-gallery" class="rg-gallery">
					<div class="rg-thumbs">
						<!-- Elastislide Carousel Thumbnail Viewer -->
						<div class="es-carousel-wrapper">
							<div class="es-nav">
								<span class="es-nav-prev">Previous</span>
								<span class="es-nav-next">Next</span>
							</div>
							<div class="es-carousel">
								<ul>
									<?php 
							if (empty ($hprodukpromo)){
								echo "Data Tidak Ada";
							}
							else{
						?>
						<?php 
						
									foreach ($hprodukpromo as $produk):
									
								?>
									<li>
									<a href="<?php echo base_url(); ?>index.php/publicdesign/profil">
										<img src="<?php echo base_url()."upload/produk/thumb/".$produk->photo;?>" 
										data-url="<?php echo base_url(); ?>index.php/publicdesign/viewpromo/<?php echo $produk->id_produk;?>/<?php echo $produk->jumlah_show;?>"
											data-large="<?php echo base_url()."upload/produk/thumb/".$produk->photo;?>" 
											alt="<?php echo base_url(); ?>index.php/publicdesign/profil" 
											
											data-description="<?php echo $produk->nama_produk."- RP". $produk->harga_produk ;?>"/></a>
								 
									</li>
									<?php
									endforeach; 
									}
								?>
									</ul>
									
							</div>
						</div>			<!-- End Elastislide Carousel Thumbnail Viewer -->
					</div><!-- rg-thumbs -->
				</div><!-- rg-gallery -->
					</div><!-- content -->
		<br/>
		</div><!-- container -->
		<center>
		<strong>Pesan Produk Promo Sekarang :) </strong>
		
		<p>
			Semua produk promo dapat dipesan dengan batas waktu yang ditentukan dan dapat digunakan dengan batas waktu sebulan setelah pemesanan <a href = "">
			Klik untuk melakukan pemesanan</a>, jadi kamu 
			tidak harus buru-buru dan dapat mendapatkan produk yang murah dengan harga miring tanpa harus pergi ke studio langsung.. 
			untuk pemesanan produk non promo anda dapat ke studio langsung yang lokasinya sangat strategis
		</p>
		</center></br>
		<div class="body4">
	<div class="main">
		<section id="content2">
			<div class="line2 wrapper">
				<div class="wrapper">
					<article class="col1">
						<h1>The Office</h1>
						
						<div class="pad">
						
							<figure class="left marg_right1 marg_left1"><img src="<?php echo base_url();?>assets/public/images/home_office_icon.png" alt="" height = "200" width = "200"><br />
				</figure>
							<br/>
							<p class="pad_bot2">
							
								<strong>
									Kantor Octopus Design and Photograph
									
								</strong>
								
							</p>
							<p>
							Provinsi : Jawa Barat</br> 
							Kabupaten : Pondok Gede </br>
							Alamat : fdvnefkvje;kferlvk,rlv </br>
							No Telephone : 02188962081</br>
							Email : <a href="#" class="link1">octopus0101@gmail.com </a>
							</p>
							
						</div>
						
					</article>
					<article class="col2 pad_left1">
						<h1>How To Order</h1><br/>
						
						<div class="pad">
							<br/>
							<figure class="left marg_right1 marg_left1"><img src="<?php echo base_url(); ?>upload/profil/<?php echo $htoorder->photo;?>" alt="" width = "200" height = "200"></figure>
							<p>
								<?php
									echo $htoorder->deskripsi;
								?>
							</p>
						</div>
					</article>
				</div>
				
			</div>
		</section>
	</div>
</div>
<!-- / content -->
<div class="main">
<!-- footer -->
	<div class="main">
<!-- footer -->
	<footer>
		<div class="wrapper">
			
			<ul id="icons">
				<li><a href="../../../../<?php echo $hprofil->link_fb;?>" class="normaltip" title="Facebook" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon1.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_twitter;?>" class="normaltip" title="Twitter" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon4.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_ins;?>" class="normaltip" title="Instagram" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/instagram.png" alt="" Width = "30" height = "30"></a></li>
				
			</ul>
		</div>
<!-- {%FOOTER_LINK} -->
	</footer>
<!-- / footer -->
</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/jquery.tmpl.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/jquery.easing.1.3.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/jquery.elastislide.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/gallery.js"></script>
    </body>
</html>