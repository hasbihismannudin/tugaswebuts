<head>
	
        <title>My Account</title>
		</head>
<section id="content">
					 <div class="wrapper">
						<h2>Hi <?php echo $this->session->userdata('nama');?> | <a href="<?php echo base_url(); ?>index.php/publicdesign/logout">Logout</a></h2>
						<div class="wrapper">	
							
							<table >
								<tr>
									<td height="500" width="300">
									<div id = "account">
									<figure class="left marg_right1"><img src="<?php echo base_url(); ?>upload/member/<?php echo $haccount->photo_member;?>" alt="" width="300" height="250"></figure>
								
									<table >
											<tr>
												
												<td width="200px" ><br />Nik:</td>
												<td width="300px" height="50"><br /><?php echo $haccount->nik;?></td>
											</tr>
											<tr>
												<td width="200px" >Nama Lengkap:</td>
												<td width="300px" height="40"><?php echo $haccount->nama_member;?></td>
											</tr>
											<tr>
												<td width="200px" >Alamat Member:</td>
												<td width="300px" height="40"><?php echo $haccount->alamat_member;?></td>
											</tr>
												<tr>
												<td width="200px">Email:</td>
												<td width="300px" height="40"><?php echo $haccount->email_member;?></td>
											</tr>
												<tr>
												<td width="200px">Telephone Member:</td>
												<td width="300px" height="40"><?php echo $haccount->tlpn_member;?></td>
											</tr>
											</tr>
												<tr>
												<td width="200px">Nama Bank:</td>
												<td width="300px" height="40"><?php echo $haccount->rekening_bank;?>&nbsp;&nbsp;&nbsp;
												
												</td>
											</tr>
											</tr>
												<tr>
												
												<td width="300px" colspan="2">
													<a href="<?php echo base_url(); ?>index.php/publicdesign/updateaccount/<?php $haccount->nik?>">Update</a> | <a href="<?php echo base_url(); ?>index.php/publicdesign/updateaccount/<?php $haccount->nik?>">Hapus Account</a>
												</td>
											</tr>
										</table>
										</div>
									
									</td>
									<td width="500" style="padding-left:70px" height="500px">
											<h2> List Pemesanan</h2>
											
											
										<div id="container1">
											
									
											<div class="container11">
										
										<table>
											<tr>
												<td width="70">ID</td>
												<td width="70">Nama Produk</td>
												<td width="70">Jumlah</td>
												<td width="70">Total Harga</td>
												<td width="70">Tanggal</td>
												 <td width="100">Persetujuan</td>
												  <td width="70">Action</td>
											</tr>
											<tr>
											<?php
											if (empty ($hlist)){
											?>
										
										<td width="70" colspan = "7">Anda Tidak Pernah Melakukan Pemesanan</td>
								
										<?php
									}
									else{
									?>
									<?php 
						
									foreach ($hlist as $list):
									?>
												<td width="70"><?php echo $list->id_pemesanan;?></td>
												<td width="70"><?php echo $list->nama_produk;?></td>
												<td width="70"><?php echo $list->jumlah_produk;?></td>
												<td width="70"><?php echo $list->total_harga;?></td>
												<td width="70"><?php echo date('d-M-Y',strtotime($list->tanggal_pemesanan));?></td>
												 <td width="100"><?php echo $list->persetujuan;?></td>
												  <td width="70">
												  	<?php
														if($this->session->userdata('akses') == "Member" && $list->persetujuan == "Disetujui"){
													?>
													<a href="<?php echo base_url(); ?>index.php/publicdesign/unduh_bukti/<?php echo $list->id_pemesanan                                                     ;?>">Cetak Bukti</a>
													<?php
													}
													?>
												  </td>
											</tr>
											<?php
									endforeach; 
									}
								?>
										</table>
										</div>
										Pesan Produk Promo <a href="<?php echo base_url(); ?>index.php/publicdesign/promo">Click Here</a>
									</td>
		
								</tr>
							</table>
							</div>
							</div>
				</section>
			</div>
		</div>
	</div>
</div>
<div class="body4">
	<div class="main">
		<section id="content2">
			<div class="line2 wrapper">
				<div class="wrapper">
					<article class="col1">
						<h2>The Office</h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php echo base_url();?>assets/public/images/home_office_icon.png" alt="" height = "100" width = "100"><br />
						<div class="pad">
							
							<p class="pad_bot2">
								<strong>
									Kantor Octopus Design and Photograph
									
								</strong>
							</p>
							
							<p>
							Provinsi&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;: Jawa Barat</br> 
							Kabupaten &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Pondok Gede </br>
							Alamat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: fdvnefkvje;kferlvk,rlv </br>
							No Telephone &nbsp;&nbsp;: 02188962081</br>
							Email &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <a href="#" class="link1">octopus0101@gmail.com </a>
							</p>
							
							
						</div>
					</article>
					<article class="col2 pad_left1">
						<h2>How To Order</h2>
						<div class="pad">
							
							<figure class="left marg_right1 marg_left1"><img src="<?php echo base_url(); ?>upload/profil/<?php echo $htoorder->photo;?>" alt="" width = "200" height = "200"></figure>
							<p>
								<?php
									echo $htoorder->deskripsi;
								?>
							</p>
						</div>
					</article>
				</div>
				
			</div>
		</section>
	</div>
</div>
<!-- / content -->
<div class="main">
<!-- footer -->
	<div class="main">
<!-- footer -->
	<footer>
		<div class="wrapper">
			<span class="left">
			 	Website template designed by <a href="http://www.templatemonster.com/" target="_blank" rel="nofollow">www.templatemonster.com</a><br>
			</span>
			<ul id="icons">
				<li><a href="../../../../<?php echo $hprofil->link_fb;?>" class="normaltip" title="Facebook" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon1.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_twitter;?>" class="normaltip" title="Twitter" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon4.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_ins;?>" class="normaltip" title="Instagram" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/instagram.png" alt="" Width = "30" height = "30"></a></li>
				
			</ul>
		</div>
<!-- {%FOOTER_LINK} -->
	</footer>
<!-- / footer -->
</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>