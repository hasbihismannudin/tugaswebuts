<?php
/*
*
* @author M.Fadli Prathama (09081003031)
* email : m.fadliprathama@gmail.com
*
*/

/* setting zona waktu */
$this->load->library('fpdf');
date_default_timezone_set('Asia/Jakarta');
$this->fpdf->FPDF("L","cm","A4");

// kita set marginnya dimulai dari kiri, atas, kanan. jika tidak diset, defaultnya 1 cm
$this->fpdf->SetMargins(1,1,1);
/* AliasNbPages() merupakan fungsi untuk menampilkan total halaman
di footer, nanti kita akan membuat page number dengan format : number page / total page
*/
$this->fpdf->AliasNbPages();

// AddPage merupakan fungsi untuk membuat halaman baru
$this->fpdf->AddPage();

// Setting Font : String Family, String Style, Font size
$this->fpdf->SetFont('Times','B',12);

$this->fpdf->Cell(30,0.7,'Bukti Pemesanan Produk Promo Octopus Design and Photograph',0,'C','C');
$this->fpdf->Line(1,2.5,30,2.5);

$this->fpdf->SetFont('Times','B',10);

$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Cell(5,0.7,'Kepada Pelanggan Setia',0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Cell(27,0.7,'Octopus Design and Photograph sebagai perusahaan jasa design dan photograph terpercaya melayani pelanggan,Menyatakan bahwa telah menerima uang',0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Cell(15,0.7,'sebagai pembayaran pemesanan produk dan telah menyetujui pemesanan produk promo berikut ini:',0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Cell(3 ,0.5, 'Id Pemesanan : ' , 0, 'L', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->id_pemesanan , 0, 'L', 'C');
$this->fpdf->Ln();

$this->fpdf->Cell(3 ,0.5, 'Nik Member : ' , 0, 'R', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->nik , 0, 'L', 'C');
$this->fpdf->Ln();

$this->fpdf->Cell(3 ,0.5, 'Nama Member : ' , 0, 'R', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->nama_member , 0, 'L', 'C');
$this->fpdf->Ln();

$this->fpdf->Cell(3 ,0.5, 'Nama Produk : ' , 0, 'R', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->nama_produk , 0, 'L', 'C');
$this->fpdf->Ln();

$this->fpdf->Cell(3 ,0.5, 'Harga Produk: ' , 0, 'R', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->harga_produk , 0, 'L', 'C');
$this->fpdf->Ln();

$this->fpdf->Cell(3 ,0.5, 'jumlah_produk : ' , 0, 'R', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->jumlah_produk , 0, 'L', 'C');
$this->fpdf->Ln();

$this->fpdf->Cell(3 ,0.5, 'Total Harga : ' , 0, 'R', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->total_harga , 0, 'L', 'C');
$this->fpdf->Ln();

$this->fpdf->Cell(3 ,0.5, 'Persetujuan : ' , 0, 'R', 'R');
$this->fpdf->Cell(7 ,0.5, $hpemesan->persetujuan , 0, 'L', 'C');
$this->fpdf->Ln();
$this->fpdf->Ln();

$this->fpdf->Cell(27,0.7,'Bukti pemesanan ini wajib di bawa saat penggunaan jasa di Octopus Design and Photograph Pondok Gede Jawa Barat. Terima kasih kepada Pelanggan telah ',0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Cell(10,0.7,'memilih Octopus Design and Photograph sebagai pilihan produk Jasa',0,'C','C');
$this->fpdf->Ln();






$this->fpdf->SetFont('Times','B',10);
$this->fpdf->Cell(3,0.7,'Pondok Gede, '.$datenow,0,'C','C');
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Cell(10,0.7,'Menyetujui,',0,'C','C');

$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Ln();
$this->fpdf->Cell(10,0.7,'Octopus Design and Photograph',0,'C','C');



$this->fpdf->Output("bukti_pemesanan.pdf","I");
?>