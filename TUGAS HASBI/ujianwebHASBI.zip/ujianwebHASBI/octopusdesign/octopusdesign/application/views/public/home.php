				<div>
					<p>
						<br/>
					</p>
				</div>
				<section id="content">
					<div class="line1">
						<div class="line2 wrapper">
						
							<div class="wrapper">
								<article class="col1">
								<h2>Login</h2>
									<form action="<?php echo base_url(); ?>index.php/publicdesign/login" method="post" enctype="multipart/form-data">
					
								<b>Username &nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;</b> <input type="text" name="username" placeholder = "username" /><br /><br />
								<b>Password &nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp; </b><input type="password" name="password_member" placeholder = "password" /><br /><br />
								<center><input type="submit" value="Login" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" value="Cancel" /></center>
								</form>
								<br/>
								
								<a href="<?php echo base_url(); ?>index.php/publicdesign/daftar_member">U want to Be Member?</a><br />	<br />
									<H2>Katalog</H2>
									<div id = "katalog">
									
									<?php 
									if (empty ($hkatalogtop3)){
										echo "Data Tidak Ada";
									}
									else{
									?>
									<?php 
						
									foreach ($hkatalogtop3 as $katalog):
									?>
										<div class="wrapper">
						
											  
												<?php echo $katalog->nama_katalog;?></br>
												Tanggal Katalog :<?php echo $katalog->tanggal_katalog;?></br>
												Jenis Produk :<?php echo $katalog->nama_jenisproduk;?></br>
												
											    Unduh Katalog : <a href = "<?php echo $katalog->link_katalog;?>">Download Here</a></br>
					
											
											</br>
										</div>
										<?php
									endforeach; 
									}
								?>
									</div>
									
								</article>
								<article class="col2 pad_left1">
										<h2>How To Order</h2>
									<figure><img src="<?php echo base_url(); ?>upload/profil/<?php echo $htoorder->photo;?>" alt="" class="pad_bot1" width = "250" height ="100"></figure>
									<div class="pad">
										<p>	
											<?php
												echo $htoorder->deskripsi;
											?>
										</p>
									</div>
								
								</article>
								<article class="col3 pad_left1">
									<h2>What’s New </h2>
									<div class="pad">
									<?php 
									if (empty ($hproduktop3)){
										echo "Data Tidak Ada";
									}
									else{
									?>
									<?php 
						
									foreach ($hproduktop3 as $produk):
									?>
										<div class="wrapper">
											<figure class="left marg_right1 marg_left1"><img src="<?php echo base_url(); ?>upload/produk/<?php echo $produk->photo;?>" alt="" width = "100" height = "70"></figure>
											
											<p>
											    <a href = "<?php echo base_url(); ?>index.php/publicdesign/viewproduct/<?php echo $produk->id_produk; ?>/<?php echo $produk->jumlah_show; ?>"><?php echo $produk->nama_produk;?></a></br>
					
												Harga Produk :<?php echo $produk->harga_produk;?></br>
												Satuan Produk :<?php echo $produk->satuan_produk;?>
											</p>
											</br>
										</div>
										<?php
									endforeach; 
									}
								?>
									</div>
								</article>
							</div>
							
						</div>
					</div>
				</section>
			</div>
		</div>
	</div>
</div>
<div class="body4">
	<div class="main">
		<section id="content2">
			<div class="line2 wrapper">
				<div class="wrapper">
					<article class="col1">
						<h2>My New Event</h2>
						<div class="wrapper">
							<figure class="left marg_right1"><img src="<?php echo base_url();?>assets/public/images/page1_img2.jpg" alt="" height = "200" width = "200"></figure>
							<p>
								<strong><?php echo $hevent->judul_event ;?></strong></br>
								<?php echo $hevent->isi_event ;?>
								</p>
						</div>
						
					</article>
					<article class="col3 pad_left1">
						<h2>My Office</h2>
						<div class="pad">
							<img src="<?php echo base_url();?>assets/public/images/home_office_icon.png" alt="" height = "100" width = "100"><br />
							<div class="wrapper">
								
								<p>
									<br>
									Provinsi : Jawa Barat</br> 
							Kabupaten : Pondok Gede </br>
							Alamat : fdvnefkvje;kferlvk,rlv </br>
							No Telephone : 02188962081</br>
							Email : <a href="#" class="link1">octopus0101@gmail.com </a>
								</p>
							</div>
						</div>
					</article>
				</div>
				
			</div>
		</section>
	</div>
</div>
<!-- / content -->
<div class="main">
<!-- footer -->
	<div class="main">
<!-- footer -->
	<footer>
		<div class="wrapper">
			
			<ul id="icons">
				<li><a href="../../../../<?php echo $hprofil->link_fb;?>" class="normaltip" title="Facebook" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon1.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_twitter;?>" class="normaltip" title="Twitter" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon4.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_ins;?>" class="normaltip" title="Instagram" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/instagram.png" alt="" Width = "30" height = "30"></a></li>
				
			</ul>
		</div>
<!-- {%FOOTER_LINK} -->
	</footer>
<!-- / footer -->
</div>
<!-- / footer -->
</div>
<script type="text/javascript"> Cufon.now(); </script>
<script type="text/javascript">
	$(document).ready(function() {
		$('#myRoundabout').roundabout({
			 shape: 'square',
			 minScale: 0.93, // tiny!
			 maxScale: 1, // tiny!
			 easing:'easeOutExpo',
			 clickToFocus:'true',
			 focusBearing:'0',
			 duration:800,
			 reflect:true
		});
	});
</script>
</body>
</html>