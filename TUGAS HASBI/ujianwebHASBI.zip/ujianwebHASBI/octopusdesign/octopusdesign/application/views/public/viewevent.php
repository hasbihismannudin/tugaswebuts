<section id="content">
					<div class="wrapper">
						<h2>Our Product </h2>
						<div class="wrapper">	
							<table>
								<tr>
								<td>
							<figure class="left marg_right1"><img src="<?php echo base_url(); ?>upload/event/<?php echo $hevent->photo_event;?>" alt="" height = "400" width = "500"></figure>
							</td>
							<td>
							<p>	
							 <strong><?php echo $hevent->judul_event ;?></strong></br>
							 Deskripsi &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<br/><?php echo $hevent->isi_event ;echo "-";echo date('d-M-Y',strtotime($hevent->tanggal_event));?></br>
							
							
							</p>	
							</td>
							</tr>
							<table>
							</br/>
							</div>
				</section>
			</div>
		</div>
	</div>
</div>
<div class="body4">
	<div class="main">
		<section id="content2">
			<div class="line2 wrapper">
				<div class="wrapper">
					<article class="col1">
						<h2>The Office</h2>
						
						<div class="pad">
						
							<figure class="left marg_right1 marg_left1"><img src="<?php echo base_url();?>assets/public/images/home_office_icon.png" alt="" height = "200" width = "180"><br />
				</figure>
							<br/>
							<p class="pad_bot2">
							
								<strong>
									Kantor Octopus Design and Photograph
									
								</strong>
								
							</p>
							<p>
							Provinsi : Jawa Barat</br> 
							Kabupaten : Pondok Gede </br>
							Alamat : fdvnefkvje;kferlvk,rlv </br>
							No Telephone : 02188962081</br>
							Email : <a href="#" class="link1">octopus0101@gmail.com </a>
							</p>
							
						</div>
						
					</article>
					<article class="col2 pad_left1">
						<h2>How To Order</h2>
						<div class="pad">
							
							<figure class="left marg_right1 marg_left1"><img src="<?php echo base_url(); ?>upload/profil/<?php echo $htoorder->photo;?>" alt="" width = "200" height = "200"></figure>
							<p>
								<?php
									echo $htoorder->deskripsi;
								?>
							</p>
						</div>
					</article>
				</div>
				
			</div>
		</section>
	</div>
</div>
<!-- / content -->
<div class="main">
<!-- footer -->
	<div class="main">
<!-- footer -->
	<footer>
		<div class="wrapper">
			<span class="left">
			 	Website template designed by <a href="http://www.templatemonster.com/" target="_blank" rel="nofollow">www.templatemonster.com</a><br>
			</span>
			<ul id="icons">
				<li><a href="../../../../<?php echo $hprofil->link_fb;?>" class="normaltip" title="Facebook" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon1.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_twitter;?>" class="normaltip" title="Twitter" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/icon4.png" alt=""></a></li>
				<li><a href="../../../../<?php echo $hprofil->link_ins;?>" class="normaltip" title="Instagram" target = "_blank"><img src="<?php echo base_url();?>assets/public/images/instagram.png" alt="" Width = "30" height = "30"></a></li>
				
			</ul>
		</div>
<!-- {%FOOTER_LINK} -->
	</footer>
<!-- / footer -->
</div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>