<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/style.css" type="text/css" media="all">
<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/cufon-yui.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/cufon-replace.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/Terminal_Dosis_300.font.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/atooltip.jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/public/js/script.js"></script>
<!--[if lt IE 9]>
	<script type="text/javascript" src="js/html5.js"></script>
	<style type="text/css">
		.bg {behavior:url(js/PIE.htc)}
	</style>
<![endif]-->
<!--[if lt IE 7]>
	<div style='clear:both;text-align:center;position:relative'>
		<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0" alt="" /></a>
	</div>
<![endif]-->
</head>
<body id="page2">
<div class="body1">
	<div class="body2">
		<div class="body3">
			<div class="main">
<!-- header -->
				<header>
					<div class="wrapper">
						<h1><a href="index.html" id="logo"></a></h1>
						<form id="search" method="post">
							<div>
								<input type="submit" class="submit" value="">
								<input class="input" type="text" value="Site Search" onblur="if(this.value=='') this.value='Site Search'" onFocus="if(this.value =='Site Search' ) this.value=''">
							</div>
						</form>
						<nav>
							<ul id="menu">
							<li ><a href="<?php echo base_url(); ?>index.php/publicdesign/home">Home</a></li>
								<li><a href="<?php echo base_url(); ?>index.php/publicdesign/profil">Profil</a></li>
								<li><a href="<?php echo base_url(); ?>index.php/publicdesign/product">Product</a></li>
								<li><a href="<?php echo base_url(); ?>index.php/publicdesign/promo">Promo</a></li>
								<li><a href="<?php echo base_url(); ?>index.php/publicdesign/event">Event </a ></li>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
								<li class="end"><a href="<?php echo base_url(); ?>index.php/publicdesign/contact">Contact</a></li>
								<?php if( $this->session->userdata('akses') == "Member"){ 
								?>
								<li class="end"><a href="<?php echo base_url(); ?>index.php/publicdesign/myaccount">Hi <?php echo $this->session->userdata('nama'); ?></a></li>
							
							
								<?php
								}
								?>
							</ul>
						</nav>
					</div>
				</header>