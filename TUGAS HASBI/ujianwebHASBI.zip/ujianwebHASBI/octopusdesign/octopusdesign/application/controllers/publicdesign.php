<?php
class Publicdesign extends CI_Controller{
	public function __construct(){
	parent::__construct();
	
	$this->load->library('session');
	$this->load->library('fpdf');
	}

	function index (){
	redirect('public/login_form');
	}
	
	function daftar_member(){
		$this->load->model('mpublic');
		$data = array();
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilevent();
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['hnik'] = $this->mpublic->ambilnik();
		$this->load->view('public/header');
		$this->load->view('public/daftar_member',$data);
	}
	
	public function submit_daftarmember(){
		
		
			$config['upload_path'] = 'upload/member/';
			$config['allowed_types'] = 'gif|jpeg|png|jpg';
			$config['max_size'] = 2000;
			$config['max_height'] = 2000;
			$config['max_width'] = 2000;
			$config['encrypt_name'] = TRUE;
			$this->upload->initialize($config);
			if ($this->upload->do_upload('photo_member')) {
				$dok = $this->upload->data();
				$this->_resize_member($dok['file_name']);
				$this->_create_thumb_member($dok['file_name']);
			$foto = $dok['file_name'];
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$tgl_lahir = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$nik = $this->input->post('nik');
			$nama_member = $this->input->post('nama_member');
				$username = $this->input->post('username');
			$password_member =  md5($this->input->post('password_member'));
			
			$alamat_member = $this->input->post('alamat_member');
			$jk_member = $this->input->post('jk_member');
			$email_member = $this->input->post('email_member');
			$tlpn_member = $this->input->post('tlpn_member');
			
			$nama_bank = $this->input->post('nama_bank');
			$rekening_bank = $this->input->post('rekening_bank');
			
			$insertmember = $this->db->query("insert into mst_member
			(nik,nama_member,tgl_lahir,alamat_member,jk_member,email_member
			,tlpn_member,photo_member,nama_bank,rekening_bank)values ('$nik','$nama_member','$tgl_lahir','$alamat_member','$jk_member',
			'$email_member','$tlpn_member','$foto','$nama_bank','$rekening_bank')");
				if($insertmember){
					$insertuser = $this->db->query("insert into mst_user(nik,username,password,akses,status)values ('$nik','$username','$password_member','Member','Aktif')");
					if($insertuser){
					redirect('publicdesign/home');
					}
				else{
					echo "gaggal insert user";
					}
				}
				
				else{
				echo "gagal insert karyawan";
				}
		}		
		
		else{
			echo "gagal upload";
		}
		
		}
		
	function login(){
		
            
		$this->load->model('mpublic');
		$this->mpublic->login();
		
		}
		function logout()
	{
		$this->session->sess_destroy();
		redirect('publicdesign/home');
	}
	function myaccount(){
		$nik = $this->session->userdata('nik');
		$this->load->model('mpublic');
		$data = array();	
		$data['htoorder'] = $this->mpublic->selecthowtoorder();	
		$data['hlist'] = $this->mpublic->ambilpemesananlist($nik);	
		$data['haccount'] = $this->mpublic->selectmyaccount($nik);
		$data['hprofil'] = $this->mpublic->selectprofil();
	$this->load->view('public/header');
		$this->load->view('public/myaccount',$data);
	}
	function updateaccount(){
		$nik = $this->session->userdata('nik');
		$this->load->model('mpublic');
		$data = array();	
		$data['htoorder'] = $this->mpublic->selecthowtoorder();	
		$data['hlist'] = $this->mpublic->ambilpemesananlist($nik);	
		$data['haccount'] = $this->mpublic->selectmyaccount($nik);
		$data['hprofil'] = $this->mpublic->selectprofil();
	    $this->load->view('public/header');
		$this->load->view('public/updateaccount',$data);
	}
	public function submit_updateacount(){
		if( $this->session->userdata('akses') == "Member"
		){
		
				$config['upload_path'] = 'upload/member/';
				$config['allowed_types'] = 'gif|jpeg|png|jpg';
				$config['max_size'] = 2000;
				$config['max_height'] = 2000;
				$config['max_width'] = 2000;
				$config['encrypt_name'] = TRUE;
				$this->upload->initialize($config);
		   
			if ($this->upload->do_upload('photo_member')) {
			//unlink gambar

				if ($query->file_name != "" || $query->file_name != NULL ){
				if(file_exists('./upload/member/' . $query->file_name) || file_exists('./upload/member/thumb/'. $query->file_name)) {
					$do = unlink('./upload/member/'. $query->file_name); //menghapus gambar semula di folder
					$do = unlink('./upload/member/thumb/'. $query->file_name); //menghapus gambar semula di folder
				}
				} 
				$dok = $this->upload->data();
				$this->_resize_member($dok['file_name']);
				$this->_create_thumb_member($dok['file_name']);
				
				$foto = $dok['file_name'];
				$nik = $this->input->post('nik');
			$nama_member = $this->input->post('nama_member');
				$username = $this->input->post('username');
			$password_baru =  md5($this->input->post('password_baru'));
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$tgl_lahir = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$alamat_member = $this->input->post('alamat_member');
			$jk_member = $this->input->post('jk_member');
			$email_member = $this->input->post('email_member');
			$tlpn_member = $this->input->post('tlpn_member');
		
			$akses = $this->input->post('akses');
			$status = $this->input->post('status');
			$nama_bank = $this->input->post('nama_bank');
			$rekening_bank = $this->input->post('rekening_bank');
				$this->load->model('mpublic');
				$this->mpublic->update_member($nik,$nama_member,$username,$password_baru,$tgl_lahir,$alamat_member
				,$jk_member,$email_member,$tlpn_member,$akses,$status,$nama_bank,$rekening_bank,$foto);
				}else{
					$nik = $this->input->post('nik');
			$nama_member = $this->input->post('nama_member');
				$username = $this->input->post('username');
			$password_baru =  md5($this->input->post('password_baru'));
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$tgl_lahir = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$alamat_member = $this->input->post('alamat_member');
			$jk_member = $this->input->post('jk_member');
			$email_member = $this->input->post('email_member');
			$tlpn_member = $this->input->post('tlpn_member');
		
			$akses = $this->input->post('akses');
			$status = $this->input->post('status');
			$nama_bank = $this->input->post('nama_bank');
			$rekening_bank = $this->input->post('rekening_bank');
					$this->load->model('mpublic');
					$this->mpublic->updatetanpamember($nik,$nama_member,$username,$password_baru,$tgl_lahir,$alamat_member
				,$jk_member,$email_member,$tlpn_member,$akses,$status,$nama_bank,$rekening_bank);
				
				
				}
				}
			else{
				redirect('auth');
			}
		
		}
	function submit_pemesanan(){
		$this->load->model('mpublic');
		$this->mpublic->submit_pemesanan();
	}
	function pemesananprodukpromo($id_produk){
		$nik = $this->session->userdata('nik');
		$this->load->model('mpublic');
		$data = array();	
		$data['htoorder'] = $this->mpublic->selecthowtoorder();	
		$data['hpromo'] = $this->mpublic->selectpromo($id_produk);	
		
		$data['haccount'] = $this->mpublic->selectmyaccount($nik);
		$data['hprofil'] = $this->mpublic->selectprofil();
		$this->load->view('public/header');
		$this->load->view('public/pemesananprodukpromo',$data);
	}
	
	
	function total_harga(){
			$nik = $this->session->userdata('nik');
		$id_produk = $this->input->post('id_produk');
		$nama_produk = $this->input->post('nama_produk');
		$harga_produk = $this->input->post('harga_produk');
		$jumlah_barang = $this->input->post('jumlah_barang');
		$total_harga = $harga_produk * $jumlah_barang;
		$this->load->model('mpublic');
		$data = array();	
		$data['htoorder'] = $this->mpublic->selecthowtoorder();	
		
		$data['haccount'] = $this->mpublic->selectmyaccount($nik);
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['id_produk'] = $id_produk;
		$data['nama_produk'] = $nama_produk;
		$data['harga_produk'] = $harga_produk;
		$data['jumlah_barang'] = $jumlah_barang;
		
	   $data['total_harga'] = $total_harga;
		
	
		$this->load->view('public/header');
		$this->load->view('public/hargatotalpesanan',$data);
	}
	
	function home(){
		$this->load->model('mpublic');
		$data = array();	
		$data['hproduktop3'] = $this->mpublic->ambilproduktop3();
		$data['htoorder'] = $this->mpublic->selecthowtoorder();	
		$data['hevent'] = $this->mpublic->ambilevent();
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['hkatalogtop3'] = $this->mpublic->ambilkatalogtop3();
		$this->load->view('public/headerhome',$data);
		$this->load->view('public/home',$data);
		
	}
	function profil(){
		$this->load->model('mpublic');
		$data = array();	
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilevent();
		$this->load->view('public/header');
		$this->load->view('public/profil',$data);
	}
	function contact(){
		$this->load->model('mpublic');
		$data = array();	
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hprofil'] = $this->mpublic->selectprofil();
			$this->load->view('public/header');
		$this->load->view('public/contact',$data);
	}
		
	function viewproduct($id_produk,$jumlah_show){
		$jum = $jumlah_show+1;
		$sql = $this->db->query("update mst_produk set jumlah_show = '$jum' where id_produk = '$id_produk'");
		if($sql){
			$this->load->model('mpublic');
		$data = array();	
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['hproduk'] = $this->mpublic->selectproduk($id_produk);
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilevent();
		$this->load->view('public/header');
		$this->load->view('public/viewproduct',$data);
		}
		
	}
	function kirimpesancontact(){
		$name = $this->input->get('name');
			$email_dari = $this->input->get('email_dari');
			$isi = $this->input->get('isi');
			
			$date = date("Y-m-d h:i:s");
			$sql = $this->db->query("insert into mst_komunikasi(name,email_dari,isi,tgl_komunikasi,status)values
			('$name','$email_dari','$isi','$date','Menerima')");
			if($sql){
				redirect('publicdesign/contact');
			}
			else{
				echo "gagal";
			}
	}
	function event(){
		$this->load->model('mpublic');
		$data = array();	
		$data['hprofil'] = $this->mpublic->selectprofil();
		
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilsemuaevent();
		$this->load->view('public/header');
		$this->load->view('public/event',$data);
		
	}
	function viewtopproduct($id_produk){
		
			$this->load->model('mpublic');
		$data = array();	
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['hproduk'] = $this->mpublic->selectproduk($id_produk);
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilevent();
		$this->load->view('public/header');
		$this->load->view('public/viewproduct',$data);
		
		
	}
	function viewevent($id_event){
		
			$this->load->model('mpublic');
		$data = array();	
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['hevent'] = $this->mpublic->selectevent($id_event);
		
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['heventall'] = $this->mpublic->ambilevent();
		$this->load->view('public/header');
		$this->load->view('public/viewevent',$data);
		
		
	}
	function jumlah_show($id_produk,$jumlah_show){
		$jum = $jumlah_show+1;
		$sql = $this->db->query("update mst_produk set jumlah_show = '$jum' where id_produk = '$id_produk'");
		if($sql){
			redirect('publicdesign/viewproduct');
		}
	}
	function viewpromo($id_produk,$jumlah_show){
		$jum = $jumlah_show+1;
		$sql = $this->db->query("update mst_produk set jumlah_show = '$jum' where id_produk = '$id_produk'");
		if($sql){
		$this->load->model('mpublic');
		$data = array();	
		$data['hprofil'] = $this->mpublic->selectprofil();
		$data['hpromo'] = $this->mpublic->selectpromo($id_produk);
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilevent();
		$this->load->view('public/header');
		$this->load->view('public/viewpromo',$data);
		}
	}
	
	
	function product(){
	$this->load->model('mpublic');
	$this->load->view('public/header');
	$data = array();
	$data['hprofil'] = $this->mpublic->selectprofil();
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilevent();
			$data['hproduk'] = $this->mpublic->ambilprodukreguler();
			$this->load->view('public/product',$data);
		
	}
	function promo(){
	$this->load->model('mpublic');
	$this->load->view('public/header');
	$data = array();
	$data['hprofil'] = $this->mpublic->selectprofil();
		$data['htoorder'] = $this->mpublic->selecthowtoorder();
		$data['hevent'] = $this->mpublic->ambilevent();
			$data['hprodukpromo'] = $this->mpublic->ambilprodukpromo();
			$this->load->view('public/promo',$data);
		
	}
	function unduh_bukti($id_pemesanan){
		if( $this->session->userdata('akses') == "Member" ){
				define('FPDF_FONTPATH',$this->config->item('fonts_path'));
			$this->load->model('madmin');
			$data = array();
			$data['hpemesan'] = $this->madmin->selectpemesan($id_pemesanan);
			$data['datenow'] =  date("d-M-Y");
			$this->load->view('public/unduh_bukti',$data);
		}else{
			redirect('publicdesign/home');
		}
	}
	 function _resize_member($fulpat) {
        $config['source_image'] = './upload/member/' . $fulpat;
        $config['new_image'] = './upload/member/' . $fulpat;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 900;
        $config['height'] = 600;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
        }
    }
	
	 function _create_thumb_member($fulpet) {
        $config['source_image'] = './upload/member/' . $fulpet;
        $config['new_image'] = './upload/member/thumb/' . $fulpet;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 200;
        //$config['height'] = 200;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo "tum" . $this->image_lib->display_errors();
        }
    }
}