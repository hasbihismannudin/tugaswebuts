<?php
class Menuadmin extends CI_Controller{
	public function __construct(){
	parent::__construct();
	
	$this->load->library('session');
	$this->load->library('fpdf');
	}
	function index(){
		if($this->session->userdata('nik') == true){
						redirect('menuadmin/karyawan');
		}
		else{
				redirect('auth');
		}
	}
	
	
	public function howtoorder(){
	if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		$this->load->model('madmin');
			$data1['hprofil'] = $this->madmin->ambilhowtoorder();
		
		}else{
				redirect('auth');
		}
	}
	public function tambahhowtoorder(){
		if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/howtoorder');
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	}
	public function submit_tambahhowtoorder(){
				if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
			$config['upload_path'] = 'upload/profil/';
			$config['allowed_types'] = 'gif|jpeg|png|jpg';
			$config['max_size'] = 2000;
			$config['max_height'] = 2000;
			$config['max_width'] = 2000;
			$config['encrypt_name'] = TRUE;
			$this->upload->initialize($config);
			if ($this->upload->do_upload('photo_howtoorder')) {
				$dok = $this->upload->data();
				$this->_resize_profil($dok['file_name']);
				$this->_create_thumb_profil($dok['file_name']);
			$foto = $dok['file_name'];
				$input_deskripsi= $this->input->post('deskripsi');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
			
			$insertevent = $this->db->query("insert into mst_profil(deskripsi,photo,keterangan)values
			('$deskripsi','$foto','howtoorder')");
				if($insertevent){
					redirect('menuadmin/howtoorder');
					}
				
				
				else{
				echo "gagal insert How To Order";
				}
		}		
		
		else{
			echo "You Must Upload Foto";
		}
		}
		else{
				redirect('auth');
		}
		
		
		}
		public function updatehowtoorder(){
			if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		$this->load->model('madmin');
			$data1['hprofil'] = $this->madmin->selecthowtoorder();
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/updatehowtoorder',$data1);
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	}
	public function submit_updatehowtoorder(){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		$config['upload_path'] = 'upload/profil/';
				$config['allowed_types'] = 'gif|jpeg|png|jpg';
				$config['max_size'] = 2000;
				$config['max_height'] = 2000;
				$config['max_width'] = 2000;
				$config['encrypt_name'] = TRUE;
				$this->upload->initialize($config);
		   
			if ($this->upload->do_upload('photo_howtoorder')) {
			//unlink gambar

				if ($query->file_name != "" || $query->file_name != NULL ){
				if(file_exists('./upload/profil/' . $query->file_name) || file_exists('./upload/profil/thumb/'. $query->file_name)) {
					$do = unlink('./upload/profil/'. $query->file_name); //menghapus gambar semula di folder
					$do = unlink('./upload/profil/thumb/'. $query->file_name); //menghapus gambar semula di folder
				}
				} 
				$dok = $this->upload->data();
				$this->_resize_event($dok['file_name']);
				$this->_create_thumb_event($dok['file_name']);
				
				$foto = $dok['file_name'];
					$input_deskripsi= $this->input->post('deskripsi');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
			
			
			
				$this->load->model('madmin');
				$this->madmin->updatehowtoorder($deskripsi,$foto);
				}else{
						$input_deskripsi= $this->input->post('deskripsi');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
			
			
			
				$this->load->model('madmin');
				$this->madmin->updatetanpafotohowtoorder($deskripsi);
				
				
				}
				}
		else{
				redirect('auth');
		}
		
	}
	public function profil(){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){

		$this->load->model('madmin');
			$data1['hprofil'] = $this->madmin->ambilprofil();
		}
		else{
				redirect('auth');
		}
	}
	public function updateprofil(){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){

		$this->load->model('madmin');
			$data1['hprofil'] = $this->madmin->selectprofil();
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/updateprofil',$data1);
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	}
	public function tambahprofil(){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){

		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/profil');
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	
	}
	public function submit_tambahprofil(){
		if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){

			$config['upload_path'] = 'upload/profil/';
			$config['allowed_types'] = 'gif|jpeg|png|jpg';
			$config['max_size'] = 2000;
			$config['max_height'] = 2000;
			$config['max_width'] = 2000;
			$config['encrypt_name'] = TRUE;
			$this->upload->initialize($config);
			if ($this->upload->do_upload('photo_profil')) {
				$dok = $this->upload->data();
				$this->_resize_profil($dok['file_name']);
				$this->_create_thumb_profil($dok['file_name']);
			$foto = $dok['file_name'];
				$input_deskripsi= $this->input->post('deskripsi');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
			
			
			$link_fb = $this->input->post('link_fb');
			$link_twitter = $this->input->post('link_twitter');
				$link_ins = $this->input->post('link_ins');
			
			
			
			
			$insertevent = $this->db->query("insert into mst_profil(deskripsi,email,link_fb,link_twitter,link_ins,photo,keterangan)values
			('$deskripsi','$email','$link_fb','$link_twitter','$link_ins','$photo','profil')");
				if($insertevent){
					redirect('menuadmin/profil');
					}
				
				
				else{
				echo "gagal insert profil";
				}
		}		
		
		else{
			echo "You Must Upload Foto";
		}
		}
		else{
				redirect('auth');
		}
		
		
		
		}
		public function submit_updateprofil(){
		if($this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){

		$config['upload_path'] = 'upload/profil/';
				$config['allowed_types'] = 'gif|jpeg|png|jpg';
				$config['max_size'] = 2000;
				$config['max_height'] = 2000;
				$config['max_width'] = 2000;
				$config['encrypt_name'] = TRUE;
				$this->upload->initialize($config);
		   
			if ($this->upload->do_upload('photo_profil')) {
			//unlink gambar

				if ($query->file_name != "" || $query->file_name != NULL ){
				if(file_exists('./upload/profil/' . $query->file_name) || file_exists('./upload/profil/thumb/'. $query->file_name)) {
					$do = unlink('./upload/profil/'. $query->file_name); //menghapus gambar semula di folder
					$do = unlink('./upload/profil/thumb/'. $query->file_name); //menghapus gambar semula di folder
				}
				} 
				$dok = $this->upload->data();
				$this->_resize_event($dok['file_name']);
				$this->_create_thumb_event($dok['file_name']);
				
				$foto = $dok['file_name'];
					$input_deskripsi= $this->input->post('deskripsi');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
			$link_fb = $this->input->post('link_fb');
			$link_twitter = $this->input->post('link_twitter');
				$link_ins = $this->input->post('link_ins');
			
			
				$this->load->model('madmin');
				$this->madmin->updateprofil($deskripsi,$link_fb,$link_twitter,$link_ins,$foto);
				}else{
						$input_deskripsi= $this->input->post('deskripsi');
			$ganti = array("'");
			$oleh = "&#039;";
				$email = $this->input->post('email');
			$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
			$link_fb = $this->input->post('link_fb');
			$link_twitter = $this->input->post('link_twitter');
				$link_ins = $this->input->post('link_ins');
			
			
				$this->load->model('madmin');
				$this->madmin->updatetanpafotoprofil($deskripsi,$email,$link_fb,$link_twitter,$link_ins);
				
				
				}
				}
		else{
				redirect('auth');
		}
		
	}
	
	function komunikasi(){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"
		| $this->session->userdata('akses') == "Karyawan Design Kreatif" | $this->session->userdata('akses') == "Pemilik"){
			$this->load->model('madmin');
			$data1['hkomunikasi'] = $this->madmin->ambilkomunikasi();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/komunikasi',$data1);
			$this->load->view('admin/footer');
		
		}else{
				redirect('auth');
		}
	}
	function balaskomunikasi($id_komunikasi){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"
		| $this->session->userdata('akses') == "Karyawan Design Kreatif" | $this->session->userdata('akses') == "Pemilik"){
			$this->load->model('madmin');
			$data1 = array();
			$data1['hprofil'] = $this->madmin->selectprofil();
			$data1['hkomunikasi'] = $this->madmin->selectkomunikasi($id_komunikasi);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/balaskomunikasi',$data1);
			$this->load->view('admin/footer');
		
		}else{
				redirect('auth');
		}
	}
	function submit_pesankomunikasi(){
	
		$id_komunikasi = $this->input->post('id_komunikasi');
		$email_dari = $this->input->post('email_dari');
		$email_kepada = $this->input->post('email_kepada');
		$date = date("Y-m-d h:i:s");
		
		$email = $this->input->post('email');
		$deskripsi = $this->input->post('deskripsi');
		$config = Array(
		'protocol'  => 'smtp',
		'smtp_host'    => 'ssl://smtp.googlemail.com',
		'smtp_port'    => 465,
		'smtp_user'    => 'masukan email',
		'smtp_pass'    => 'pass',
		'mailtype'     => 'html',
		'charset'      => 'iso-8859-1',
		'newline'   => "\r\n"
		);
$this->load->library('email', $config);
 
		
		$this->email->from("masukan email"); 
		$this->email->to($email_kepada);  //diisi dengan alamat tujuan
		$this->email->subject('Octopus Design'); 
		$this->email->message($deskripsi); 
		$ok = $this->email->send();
		if($ok){
			$this->load->model('madmin');
			 $this->madmin->updatestatuskomunikasi($id_komunikasi);
		}
		else{
			echo "gagal";
		}
	}
	public function delete_komunikasi($id_komunikasi){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"
		| $this->session->userdata('akses') == "Karyawan Design Kreatif" | $this->session->userdata('akses') == "Pemilik"){
			$hapus = $this->db->delete('mst_komunikasi',array('id_komunikasi' => $id_komunikasi));
			if($hapus){
				redirect('menuadmin/komunikasi');
			}else{
					echo "gagal delete produk";
			}
		}
		else{
				redirect('auth');
		}
	}	
	public function event(){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		$this->load->model('madmin');
			$data1['hevent'] = $this->madmin->ambilevent();
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/event',$data1);
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	
	}
	public function updateevent($id_event){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		$this->load->model('madmin');
			$data1['hevent'] = $this->madmin->selectevent($id_event);
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/updateevent',$data1);
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	
	}
	public function viewevent($id_event){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		$this->load->model('madmin');
			$data1['hevent'] = $this->madmin->selectevent($id_event);
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/viewevent',$data1);
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	
	}
	
	public function submit_tambahevent(){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
			$config['upload_path'] = 'upload/event/';
			$config['allowed_types'] = 'gif|jpeg|png|jpg';
			$config['max_size'] = 2000;
			$config['max_height'] = 2000;
			$config['max_width'] = 2000;
			$config['encrypt_name'] = TRUE;
			$this->upload->initialize($config);
			if ($this->upload->do_upload('photo_event')) {
				$dok = $this->upload->data();
				$this->_resize_event($dok['file_name']);
				$this->_create_thumb_event($dok['file_name']);
			$foto = $dok['file_name'];
			
			$judul_event = $this->input->post('judul_event');
			$input_event= $this->input->post('isi_event');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$isi_event = str_replace($ganti, $oleh, $input_event);
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$tanggal_event = $dt1[2]."-".$dt1[1]."-".$dt1[0];
		
			
			$insertevent = $this->db->query("insert into mst_event(judul_event,isi_event,tanggal_event,photo_event)values
			('$judul_event','$isi_event','$tanggal_event','$foto')");
				if($insertevent){
					redirect('menuadmin/event');
					}
				
				
				else{
				echo "gagal insert event";
				}
			}		
		
			else{
			echo "gagal upload";
			}
			
		}
		else{
			redirect('auth');
		}
	}
		public function submit_updateevent(){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		
	         	$config['upload_path'] = 'upload/event/';
				$config['allowed_types'] = 'gif|jpeg|png|jpg';
				$config['max_size'] = 2000;
				$config['max_height'] = 2000;
				$config['max_width'] = 2000;
				$config['encrypt_name'] = TRUE;
				$this->upload->initialize($config);
		   
			if ($this->upload->do_upload('photo_event')) {
			//unlink gambar

				if ($query->file_name != "" || $query->file_name != NULL ){
				if(file_exists('./upload/event/' . $query->file_name) || file_exists('./upload/event/thumb/'. $query->file_name)) {
					$do = unlink('./upload/event/'. $query->file_name); //menghapus gambar semula di folder
					$do = unlink('./upload/event/thumb/'. $query->file_name); //menghapus gambar semula di folder
				}
				} 
				$dok = $this->upload->data();
				$this->_resize_event($dok['file_name']);
				$this->_create_thumb_event($dok['file_name']);
				
				$foto = $dok['file_name'];
				$id_event = $this->input->post('id_event');
				$judul_event = $this->input->post('judul_event');
				$input_event= $this->input->post('isi_event');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$isi_event = str_replace($ganti, $oleh, $input_event);
			
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$tanggal_event = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			
			
				$this->load->model('madmin');
				$this->madmin->updateevent($id_event,$judul_event,$isi_event,$tanggal_event,$foto);
				}else{
				$id_event = $this->input->post('id_event');
				$judul_event = $this->input->post('judul_event');
				$input_event= $this->input->post('isi_event');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$isi_event = str_replace($ganti, $oleh, $input_event);
			
				$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$tanggal_event = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			
				$this->load->model('madmin');
				$this->madmin->updatetanpafotoevent($id_event,$judul_event,$isi_event,$tanggal_event);
				
				
				}
				}
		else{
				redirect('auth');
		}
		
	}
		public function delete_event($id_event){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		
		$this->load->model('madmin');
		$this->madmin->delete_event($id_event);
						}
		else{
				redirect('auth');
		}
		
		
	}
		public function tambahevent(){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin"){
		
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/tambahevent');
		$this->load->view('admin/footer');
		}
		else{
				redirect('auth');
		}
	
	}
		public function jenisproduk(){
			if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin"){
		
		$this->load->model('madmin');
			$data1['hjenisproduk'] = $this->madmin->ambiljenisproduk();
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/jenisproduk',$data1);
		$this->load->view('admin/footer');
			}
		else{
				redirect('auth');
		}
	}
	public function tambahjenisproduk(){
		
				if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin"){
		
		
		
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/tambah_jenisproduk');
		$this->load->view('admin/footer');
					}
		else{
				redirect('auth');
		}
	}
	function submit_tambahjenisproduk(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin"){
			$this->load->model('madmin');
			$this->madmin->tambahjenisproduk();
			redirect('menuadmin/jenisproduk');
		}
		else{
				redirect('auth');
		}	
	}
	public function delete_jenisproduk($id_jenisproduk){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin"){
		$this->load->model('madmin');
		$this->madmin->delete_jenisproduk($id_jenisproduk);
		}
		else{
				redirect('auth');
		}	
	}
	public function updatejenisproduk($id_jenisproduk){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin"){
			$this->load->model('madmin');
			$data1['hjenisproduk'] = $this->madmin->selectjenisproduk($id_jenisproduk);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/updatejenisproduk',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}	
	}
	public function submit_updatejenisproduk(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin"){
		
			$id_jenisproduk = $this->input->post('id_jenisproduk');
			$keterangan = $this->input->post('keterangan');
				$nama_jenisproduk = $this->input->post('nama_jenisproduk');                                                                                                                                                                                                                                                                                                                                                                                      
				
				$this->load->model('madmin');
				$this->madmin->updatejenisproduk($id_jenisproduk,$nama_jenisproduk,$keterangan);
		}
		else{
			redirect('auth');
		}	
			
	}
	function submit_persetujuan(){
		if( $this->session->userdata('akses') == "Pemilik" ){
			$id_produk = $this->input->post('id_produk');
			$persetujuan = $this->input->post('persetujuan');
			$this->load->model('madmin');
			$this->madmin->persetujuan($id_produk,$persetujuan);
			
		}
		else{
			redirect('auth');
		}
	}
	public function tambahproduk(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		){
		
		$this->load->model('madmin');
			$data1['hjenisproduk'] = $this->madmin->ambiljenisproduk();
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/tambahproduk',$data1);
		$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}	
	}
		public function produk(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		| $this->session->userdata('akses') == "Pemilik" ){
		
			$this->load->model('madmin');
			$data1['hproduk'] = $this->madmin->ambilproduk();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/produk',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}		
	
	}
	public function updateproduk($id_produk){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		 ){
			$this->load->model('madmin');
			$data = array();
			$data1['hjenisproduk'] = $this->madmin->ambiljenisproduk();
			$data1['hproduk'] = $this->madmin->selectproduk($id_produk);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/updateproduk',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}		
	
	}
	public function persetujuan($id_produk){
		if($this->session->userdata('akses') == "Pemilik" 
		 ){
			$this->load->model('madmin');
			$data = array();
			
			$data1['hproduk'] = $this->madmin->selectproduk($id_produk);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/persetujuan',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}		
	
	}
	public function delete_produk($id_produk){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		| $this->session->userdata('akses') == "Pemilik" ){
		
			$this->load->model('madmin');
			$this->madmin->delete_produk($id_produk);
		}
		else{
			redirect('auth');
		}
	}
	public function submit_tambahproduk(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		 ){
		
			$config['upload_path'] = 'upload/produk/';
			$config['allowed_types'] = 'gif|jpeg|png|jpg';
			$config['max_size'] = 2000;
			$config['max_height'] = 2000;
			$config['max_width'] = 2000;
			$config['encrypt_name'] = TRUE;
			$this->upload->initialize($config);
			if ($this->upload->do_upload('photo_produk')) {
				$dok = $this->upload->data();
				$this->_resize_produk($dok['file_name']);
				$this->_create_thumb_produk($dok['file_name']);
			$foto = $dok['file_name'];
				$input_deskripsi= $this->input->post('deskripsi');
			$ganti = array("'");
			$oleh = "&#039;";
			
			$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
			$nama_produk = $this->input->post('nama_produk');
			$id_jenisproduk = $this->input->post('id_jenisproduk');
			$harga_produk = $this->input->post('harga_produk');
			$jumlah_produk = $this->input->post('jumlah_produk');
			$satuan_produk = $this->input->post('satuan_produk');
			
			$kategori = $this->input->post('kategori');
			$persetujuan = $this->input->post('persetujuan');
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$dari_tanggal = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$dt2 = array(
			$this->input->post('tgl2'),
			$this->input->post('bln2'),
			$this->input->post('thn2'));
		$sampai_tanggal = $dt2[2]."-".$dt2[1]."-".$dt2[0];
			
			

			

			$insertevent = $this->db->query("insert into mst_produk(nama_produk,id_jenisproduk,deskripsi,harga_produk,jumlah_produk,satuan_produk
			,dari_tanggal,sampai_tanggal,kategori,photo,persetujuan)values
			('$nama_produk','$id_jenisproduk','$deskripsi','$harga_produk','$jumlah_produk','$satuan_produk'
			,'$dari_tanggal','$sampai_tanggal','$kategori','$foto','$persetujuan')");
				if($insertevent){
					redirect('menuadmin/tambahproduk');
					}
				
				
				else{
				echo "gagal insert How To Order";
				}
		}		
		
		else{
			echo "You Must Upload Foto";
		}
		}
		else{
			redirect('auth');
		}
		
		}
		
		public function submit_updateproduk(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		){
		
				$config['upload_path'] = 'upload/produk/';
				$config['allowed_types'] = 'gif|jpeg|png|jpg';
				$config['max_size'] = 2000;
				$config['max_height'] = 2000;
				$config['max_width'] = 2000;
				$config['encrypt_name'] = TRUE;
				$this->upload->initialize($config);
		   
			if ($this->upload->do_upload('photo_produk')) {
			//unlink gambar

				if ($query->file_name != "" || $query->file_name != NULL ){
				if(file_exists('./upload/produk/' . $query->file_name) || file_exists('./upload/produk/thumb/'. $query->file_name)) {
					$do = unlink('./upload/produk/'. $query->file_name); //menghapus gambar semula di folder
					$do = unlink('./upload/produk/thumb/'. $query->file_name); //menghapus gambar semula di folder
				}
				} 
				$dok = $this->upload->data();
				$this->_resize_event($dok['file_name']);
				$this->_create_thumb_event($dok['file_name']);
				
				$foto = $dok['file_name'];
				$input_deskripsi= $this->input->post('deskripsi');
				$ganti = array("'");
				$oleh = "&#039;";
			
				$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
				$nama_produk = $this->input->post('nama_produk');
				$id_produk = $this->input->post('id_produk');
				$id_jenisproduk = $this->input->post('id_jenisproduk');
				$harga_produk = $this->input->post('harga_produk');
				$jumlah_produk = $this->input->post('jumlah_produk');
				$satuan_produk = $this->input->post('satuan_produk');
				$kategori = $this->input->post('kategori');
				$persetujuan = $this->input->post('persetujuan');
				$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$dari_tanggal = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$dt2 = array(
			$this->input->post('tgl2'),
			$this->input->post('bln2'),
			$this->input->post('thn2'));
			$sampai_tanggal = $dt2[2]."-".$dt2[1]."-".$dt2[0];
			
			
				$this->load->model('madmin');
				$this->madmin->updateproduk($id_produk,$deskripsi,$nama_produk,$id_jenisproduk,$harga_produk,$jumlah_produk,$satuan_produk,$dari_tanggal,$sampai_tanggal,$kategori,$persetujuan,$foto);
				}else{
					$input_deskripsi= $this->input->post('deskripsi');
					$ganti = array("'");
					$oleh = "&#039;";
					$id_produk = $this->input->post('id_produk');
					$deskripsi = str_replace($ganti, $oleh, $input_deskripsi);
					$nama_produk = $this->input->post('nama_produk');
					$id_jenisproduk = $this->input->post('id_jenisproduk');
					$harga_produk = $this->input->post('harga_produk');
					$jumlah_produk = $this->input->post('jumlah_produk');
					$satuan_produk = $this->input->post('satuan_produk');
					$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$dari_tanggal = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$dt2 = array(
			$this->input->post('tgl2'),
			$this->input->post('bln2'),
			$this->input->post('thn2'));
			$sampai_tanggal = $dt2[2]."-".$dt2[1]."-".$dt2[0];
			
			
					$kategori = $this->input->post('kategori');
					$persetujuan = $this->input->post('persetujuan');
			
					$this->load->model('madmin');
					$this->madmin->updatetanpafotoproduk($id_produk,$deskripsi,$nama_produk,$id_jenisproduk,$harga_produk,$jumlah_produk,$satuan_produk,$dari_tanggal,$sampai_tanggal,$kategori,$persetujuan);
				
				
				}
				}
			else{
				redirect('auth');
			}
		
		}
		function daftarpemesan(){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		
			$this->load->model('madmin');
			$data1['hpemesan'] = $this->madmin->daftarpemesan();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/daftarpemesan',$data1);
			$this->load->view('admin/footer');
		}else{
			redirect('auth');
		}
		}
		function persetujuan_pemesanan($id_pemesanan){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		
			$this->load->model('madmin');
			$data1['hpemesan'] = $this->madmin->selectpemesan($id_pemesanan);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/persetujuanpemesanan',$data1);
			$this->load->view('admin/footer');
		}else{
			redirect('auth');
		}
		}
		function submit_persetujuanpemesanan(){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
			
			$this->load->model('madmin');
			$this->madmin->submit_persetujuanpemesanan();
		}else{
			redirect('auth');
		}
		}
		public function requestlaporanproduk(){
		if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		
			$this->load->model('madmin');
			$data1['hpemilik'] = $this->madmin->ambilpemilik();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/requestlaporanproduk',$data1);
			$this->load->view('admin/footer');
		}else{
			redirect('auth');
		}
		}
		public function requestlaporanpromosi(){
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		
		$this->load->model('madmin');
			$data1['hpemilik'] = $this->madmin->ambilpemilik();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/requestlaporanpromosi',$data1);
			$this->load->view('admin/footer');
			}else{
				redirect('auth');
			}
		}
		 function laporanproduk()
		{
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		
		define('FPDF_FONTPATH',$this->config->item('fonts_path'));
		// Load view “pdf_report” untuk menampilkan hasilnya
			$nik = $this->input->post('nikmarketing');
			$this->load->model('madmin');
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$dari_tanggal = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$dt2 = array(
			$this->input->post('tgl2'),
			$this->input->post('bln2'),
			$this->input->post('thn2'));
		$sampai_tanggal = $dt2[2]."-".$dt2[1]."-".$dt2[0];
		
			$data1 = array();
			$data1['hpemilik'] = $this->madmin->ambilpemilik();
			$data1['hproduk'] = $this->madmin->ambilproduk2($dari_tanggal,$sampai_tanggal);
			$data1['dari'] = $dari_tanggal;
			$data1['sampai'] = $sampai_tanggal;
			$data1['datenow'] =  date("d-M-Y");
			$data1['hmarketing'] = $this->madmin->select1($nik);
		$this->load->view('admin/laporanproduk',$data1);
		}else{
			redirect('auth');
		}
		}
		 function laporanpromosi()
		{
			if( $this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Admin" ){
		
		define('FPDF_FONTPATH',$this->config->item('fonts_path'));
		// Load view “pdf_report” untuk menampilkan hasilnya
			$nik = $this->input->post('nikmarketing');
			$this->load->model('madmin');
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$dari_tanggal = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$dt2 = array(
			$this->input->post('tgl2'),
			$this->input->post('bln2'),
			$this->input->post('thn2'));
		$sampai_tanggal = $dt2[2]."-".$dt2[1]."-".$dt2[0];
		
			$data1 = array();
			$data1['hpemilik'] = $this->madmin->ambilpemilik();
			$data1['hpromosi'] = $this->madmin->ambilpromosi($dari_tanggal,$sampai_tanggal);
			$data1['dari'] = $dari_tanggal;
			$data1['sampai'] = $sampai_tanggal;
			$data1['datenow'] =  date("d-M-Y");
			$data1['hmarketing'] = $this->madmin->select1($nik);
		$this->load->view('admin/laporanpromosi',$data1);
		}else{
			redirect('auth');
		}
		}
		public function coba(){
		$dt1 = array(
		$this->input->post('tgl'),
		$this->input->post('bln'),
		$this->input->post('thn')
		
		);
		$tanggal = $dt1[2]."-".$dt1[1]."-".$dt1[0];
		echo $tanggal;
		}
			public function member(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		|$this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Pemilik"){
		
			$this->load->model('madmin');
			$data1['hmember'] = $this->madmin->member();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/member',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}
	}
	public function view_member($nik){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" 
		|$this->session->userdata('akses') == "Karyawan Marketing" | $this->session->userdata('akses') == "Pemilik"){
		
			$this->load->model('madmin');
			$data1['hmember'] = $this->madmin->selectmember($nik);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/viewmember',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}
	}
	public function katalog(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){
		
			$this->load->model('madmin');
			$data1['hkatalog'] = $this->madmin->ambilkatalog();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/katalog',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}
	}
	public function viewkatalog($id_katalog){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){
			$this->load->model('madmin');
			$data1['hkatalog'] = $this->madmin->selectkatalog($id_katalog);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/viewkatalog',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}
	}
	public function tambahkatalog(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){
			
			$this->load->model('madmin');
			$data1['hjenisproduk'] = $this->madmin->ambiljenisproduk();
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/tambahkatalog',$data1);
			$this->load->view('admin/footer');
		}
		else{
			redirect('auth');
		}
	}
	function submit_tambahkatalog(){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){
			
			$this->load->model('madmin');
			$this->madmin->tambahkatalog();
			redirect('menuadmin/katalog');
		}
		else{
			redirect('auth');
		}
	}
	function deletekatalog($id_katalog){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){
			
			$this->load->model('madmin');
			$this->madmin->deletekatalog($id_katalog);
			redirect('menuadmin/katalog');
		}
		else{
			redirect('auth');
		}
	}	
	function submit_updatekatalog($id_katalog){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){
		
			$this->load->model('madmin');
			$this->madmin->updatekatalog($id_katalog);
			redirect('menuadmin/katalog');
		}
		else{
			redirect('auth');
		}
	}
function updatekatalog($id_katalog){
		if( $this->session->userdata('akses') == "Karyawan Kreatif Design" | $this->session->userdata('akses') == "Admin" ){
		
			
			$this->load->model('madmin');
			$data = array();
			$data['hjenisproduk'] = $this->madmin->ambiljenisproduk();
			$data['hkatalog'] = $this->madmin->selectkatalog($id_katalog);
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/updatekatalog',$data);
			$this->load->view('admin/footer');
			}
		else{
			redirect('auth');
		}
}
	public function data_diri(){
	if($this->session->userdata('nik') == true){	
	$nik = $this->session->userdata('nik');
		$this->load->model('madmin');
			$data1['hkaryawan'] = $this->madmin->select1($nik);
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/datadiri',$data1);
		$this->load->view('admin/footer');
	}
	else{
		redirect('auth');
	}
	}
	public function karyawan(){
		if($this->session->userdata('nik') == true){
		$this->load->model('madmin');
			$data1['hkaryawan'] = $this->madmin->ambilkaryawan();
			
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/vkaryawan',$data1);
		$this->load->view('admin/footer');
		}
	else{
		redirect('auth');
	}
	
	}
	public function viewkaryawan($nik){
		if($this->session->userdata('nik') == true){
		$this->load->model('madmin');
			$data1['hkaryawan'] = $this->madmin->select1($nik);
			
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/viewkaryawan',$data1);
		$this->load->view('admin/footer');
		}
	else{
		redirect('auth');
	}
	
	}
	public function update_karyawan($nik){
		if($this->session->userdata('akses') == "Admin"){
		$this->load->model('madmin');
			$data['hkaryawan'] = $this->madmin->select1($nik);
			
		$this->load->view('admin/header');
		$this->load->view('admin/nav');
		$this->load->view('admin/update_karyawan',$data);
		$this->load->view('admin/footer');
		}
	else{
		redirect('auth');
	}
	
	}
	public function submit_updatekaryawan(){
		if( $this->session->userdata('akses') == "Pemilik" | $this->session->userdata('akses') == "Admin" 
		){
		
				$config['upload_path'] = 'upload/karyawan/';
				$config['allowed_types'] = 'gif|jpeg|png|jpg';
				$config['max_size'] = 2000;
				$config['max_height'] = 2000;
				$config['max_width'] = 2000;
				$config['encrypt_name'] = TRUE;
				$this->upload->initialize($config);
		   
			if ($this->upload->do_upload('gambar_karyawan')) {
			//unlink gambar

				if ($query->file_name != "" || $query->file_name != NULL ){
				if(file_exists('./upload/karyawan/' . $query->file_name) || file_exists('./upload/karyawan/thumb/'. $query->file_name)) {
					$do = unlink('./upload/karyawan/'. $query->file_name); //menghapus gambar semula di folder
					$do = unlink('./upload/karyawan/thumb/'. $query->file_name); //menghapus gambar semula di folder
				}
				} 
				$dok = $this->upload->data();
				$this->_resize_karyawan($dok['file_name']);
				$this->_create_thumb_karyawan($dok['file_name']);
				
				$foto = $dok['file_name'];
				$nik = $this->input->post('nik');
			$nama_karyawan = $this->input->post('nama_karyawan');
				$username = $this->input->post('username');
			$password_baru =  md5($this->input->post('password_baru'));
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$tgl_lahir = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$alamat_karyawan = $this->input->post('alamat_karyawan');
			$jk_karyawan = $this->input->post('jk_karyawan');
			$email_karyawan = $this->input->post('email_karyawan');
			$tlp_karyawan = $this->input->post('tlp_karyawan');
			$jabatan_karyawan = $this->input->post('jabatan_karyawan');
			$akses = $this->input->post('akses');
			$status = $this->input->post('status');
				
				$this->load->model('madmin');
				$this->madmin->update_karyawan($nik,$nama_karyawan,$username,$password_baru,$tgl_lahir ,$alamat_karyawan
				,$jk_karyawan,$email_karyawan,$tlp_karyawan,$jabatan_karyawan,$akses,$status,$foto);
				}else{
					$nik = $this->input->post('nik');
			$nama_karyawan = $this->input->post('nama_karyawan');
				$username = $this->input->post('username');
			$password_baru =  md5($this->input->post('password_baru'));
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
		$tgl_lahir = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$alamat_karyawan = $this->input->post('alamat_karyawan');
			$jk_karyawan = $this->input->post('jk_karyawan');
			$email_karyawan = $this->input->post('email_karyawan');
			$tlp_karyawan = $this->input->post('tlp_karyawan');
			$jabatan_karyawan = $this->input->post('jabatan_karyawan');
			$akses = $this->input->post('akses');
			$status = $this->input->post('status');
					$this->load->model('madmin');
					$this->madmin->updatetanpafotokaryawan($nik,$nama_karyawan,$username,$password_baru,$tgl_lahir,$alamat_karyawan
				,$jk_karyawan,$email_karyawan,$tlp_karyawan,$jabatan_karyawan,$akses,$status);
				
				
				}
				}
			else{
				redirect('auth');
			}
		
		}
	public function tambahkaryawan(){
		if( $this->session->userdata('akses') == "Pemilik" | $this->session->userdata('akses') == "Admin" ){
		
			$this->load->view('admin/header');
			$this->load->view('admin/nav');
			$this->load->view('admin/tambahkaryawan');
			$this->load->view('admin/footer');
		}
		else{
		redirect('auth');
		}
	}
	public function submit_tambahkaryawan(){
		if( $this->session->userdata('akses') == "Pemilik" | $this->session->userdata('akses') == "Admin" ){
		
			$config['upload_path'] = 'upload/karyawan/';
			$config['allowed_types'] = 'gif|jpeg|png|jpg';
			$config['max_size'] = 2000;
			$config['max_height'] = 2000;
			$config['max_width'] = 2000;
			$config['encrypt_name'] = TRUE;
			$this->upload->initialize($config);
			if ($this->upload->do_upload('gambar_karyawan')) {
				$dok = $this->upload->data();
				$this->_resize_karyawan($dok['file_name']);
				$this->_create_thumb_karyawan($dok['file_name']);
			$foto = $dok['file_name'];
			
			$nik = $this->input->post('nik');
			$nama_karyawan = $this->input->post('nama_karyawan');
				$username = $this->input->post('username');
			$password =  md5($this->input->post('password'));
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$tgl_lahir = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			$alamat_karyawan = $this->input->post('alamat_karyawan');
			$jk_karyawan = $this->input->post('jk_karyawan');
			$email_karyawan = $this->input->post('email_karyawan');
			$tlp_karyawan = $this->input->post('tlp_karyawan');
			$jabatan_karyawan = $this->input->post('jabatan_karyawan');
			$akses = $this->input->post('akses');
			$status = $this->input->post('status');
			
			$insertkaryawan = $this->db->query("insert into mst_karyawan(nik,nama_karyawan,tgl_lahir,alamat_karyawan,jk_karyawan,email_karyawan
			,tlpn_karyawan,jabatan_karyawan,photo_karyawan)values ('$nik','$nama_karyawan','$tgl_lahir','$alamat_karyawan','$jk_karyawan',
			'$email_karyawan','$tlp_karyawan','$jabatan_karyawan','$foto')");
				if($insertkaryawan){
					$insertuser = $this->db->query("insert into mst_user(nik,username,password,akses,status)values ('$nik','$username','$password','$akses','$status')");
					if($insertuser){
					redirect('menuadmin/karyawan');
					}
				else{
					echo "gaggal insert user";
					}
				}
				
				else{
				echo "gagal insert karyawan";
				}
		}		
		
		else{
			echo "gagal upload";
		}
		
		}
		else{
		redirect('auth');
		}
	}
		public function _resize_karyawan($fulpat) {
        $config['source_image'] = './upload/karyawan/' . $fulpat;
        $config['new_image'] = './upload/karyawan/' . $fulpat;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 900;
        $config['height'] = 600;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
        }
    }
	
		public function _create_thumb_karyawan($fulpet) {
        $config['source_image'] = './upload/karyawan/' . $fulpet;
        $config['new_image'] = './upload/karyawan/thumb/' . $fulpet;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 200;
        //$config['height'] = 200;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo "tum" . $this->image_lib->display_errors();
        }
    }
	public function _resize_event($fulpat) {
        $config['source_image'] = './upload/event/' . $fulpat;
        $config['new_image'] = './upload/event/' . $fulpat;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 900;
        $config['height'] = 600;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
        }
    }
	
		public function _create_thumb_event($fulpet) {
        $config['source_image'] = './upload/event/' . $fulpet;
        $config['new_image'] = './upload/event/thumb/' . $fulpet;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 200;
        //$config['height'] = 200;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo "tum" . $this->image_lib->display_errors();
        }
    }
	
	
	public function delete_karyawan($nik){
		$this->load->model('madmin');
		$this->madmin->deletekaryawan($nik);
		
	}
	
		public function _resize_profil($fulpat) {
        $config['source_image'] = './upload/profil/' . $fulpat;
        $config['new_image'] = './upload/profil/' . $fulpat;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 900;
        $config['height'] = 600;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
        }
    }
	
		public function _create_thumb_profil($fulpet) {
        $config['source_image'] = './upload/profil/' . $fulpet;
        $config['new_image'] = './upload/profil/thumb/' . $fulpet;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 200;
        //$config['height'] = 200;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo "tum" . $this->image_lib->display_errors();
        }
    }
		public function _resize_produk($fulpat) {
        $config['source_image'] = './upload/produk/' . $fulpat;
        $config['new_image'] = './upload/produk/' . $fulpat;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 900;
        $config['height'] = 600;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
        }
    }
	
		public function _create_thumb_produk($fulpet) {
        $config['source_image'] = './upload/produk/' . $fulpet;
        $config['new_image'] = './upload/produk/thumb/' . $fulpet;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 200;
        //$config['height'] = 200;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->resize()) {
            echo "tum" . $this->image_lib->display_errors();
        }
    }
	
	}	
	
	

    
	
