<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Auth extends CI_controller{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->library('security');
		$this->load->library('session');
		$this->load->model('mauth');
		
	}
	function index()
	{
	
		$this->load->view('auth/login_form');
	}
	 function validate_credentials()
	{

        
           
            
		$this->mauth->validate();
		
	}
	function signup()
	{
		$data['main_content'] = 'signup_form';
		$this->load->view('includes/template', $data);
	}
 
	function logout()
	{
		$this->session->sess_destroy();
		$this->index();
	}
}
