<?php
	class Madmin extends CI_Model{
		function select1($nik){
			return $select1 = $this->db->query("select mst_user.nik,mst_user.username,mst_karyawan.nama_karyawan,mst_user.password,mst_karyawan.tgl_lahir,
			mst_karyawan.alamat_karyawan,mst_karyawan.jk_karyawan,mst_karyawan.email_karyawan,mst_karyawan.tlpn_karyawan,mst_karyawan.jabatan_karyawan
			,mst_karyawan.photo_karyawan,mst_user.status,mst_user.akses from mst_user,mst_karyawan where mst_user.nik =  mst_karyawan.nik
			and	mst_user.status = 'Aktif'  and mst_user.nik = '$nik'")->row();	
		}
		
		function ambilkaryawan(){
			$ambilkaryawan = $this->db->query("select nik,nama_karyawan,tgl_lahir,
		alamat_karyawan,jabatan_karyawan
			from mst_karyawan ");
			if($ambilkaryawan->num_rows()> 0){
				foreach($ambilkaryawan->result() as $data1){
					$hkaryawan[] = $data1;
				}
				return $hkaryawan;
			}
		}
		function update_karyawan($nik,$nama_karyawan,$username,$password_baru,$tgl_lahir ,$alamat_karyawan
				,$jk_karyawan,$email_karyawan,$tlp_karyawan,$jabatan_karyawan,$akses,$status,$foto){
			$sql = $this->db->query("update mst_karyawan set nama_karyawan = '$nama_karyawan',tgl_lahir = '$tgl_lahir'
			,alamat_karyawan = '$alamat_karyawan',jk_karyawan = '$jk_karyawan',email_karyawan = '$email_karyawan'
			,tlpn_karyawan = '$tlp_karyawan',jabatan_karyawan = '$jabatan_karyawan',photo_karyawan = '$foto' where nik = '$nik'");
			if($sql){
			if($password_baru == ""){
				$user = $this->db->query("update mst_user set username = '$username',akses = '$akses',status = '$status'
				where nik = '$nik'");
				if($user){
					redirect('menuadmin/karyawan');
				}
				else{
				ECHO "GAGAL USER";
				}
			}else{
				$user = $this->db->query("update mst_user set username = '$username',password = '$password_baru',akses = '$akses',status = '$status'
				where nik = '$nik'");
				if($user){
					redirect('menuadmin/karyawan');
				}
				else{
				ECHO "GAGAL USER";
				}
			}
			}
			else{
				echo "gagal";
			}
		}
		function updatetanpafotokaryawan($nik,$nama_karyawan,$username,$password_baru,$tgl_lahir ,$alamat_karyawan
				,$jk_karyawan,$email_karyawan,$tlp_karyawan,$jabatan_karyawan,$akses,$status){
			$sql = $this->db->query("update mst_karyawan set nama_karyawan = '$nama_karyawan',tgl_lahir = '$tgl_lahir'
			,alamat_karyawan = '$alamat_karyawan',jk_karyawan = '$jk_karyawan',email_karyawan = '$email_karyawan'
			,tlpn_karyawan = '$tlp_karyawan',jabatan_karyawan = '$jabatan_karyawan' where nik = '$nik'");
			if($sql){
			if($password_baru == ""){
				$user = $this->db->query("update mst_user set username = '$username',akses = '$akses',status = '$status'
				where nik = '$nik'");
				if($user){
					redirect('menuadmin/karyawan');
				}
				else{
				ECHO "GAGAL USER";
				}
			}else{
				$user = $this->db->query("update mst_user set username = '$username',password = '$password_baru',akses = '$akses',status = '$status'
				where nik = '$nik'");
				if($user){
					redirect('menuadmin/karyawan');
				}
				else{
				ECHO "GAGAL USER";
				}
			}
			}
			else{
				echo "gagal";
			}
		}
		function ambilevent(){
			$ambilevent = $this->db->query("select id_event,judul_event,isi_event,tanggal_event,photo_event
		
			from mst_event");
			if($ambilevent->num_rows()> 0){
				foreach($ambilevent->result() as $data1){
					$hevent[] = $data1;
				}
				return $hevent;
			}
		}
		function selectevent($id_event){
			return $selectevent = $this->db->query("select id_event,judul_event,isi_event,tanggal_event,photo_event
		
			from mst_event where id_event = '$id_event' ")->row();	
		}
		function deletekaryawan($nik){
			$sql1 = $this->db->delete('mst_user',array('nik' => $nik));
			if($sql1){
				$sql2 = $this->db->delete('mst_karyawan',array('nik' => $nik));
				if($sql2){
					redirect('menuadmin/karyawan');
				}
				else{
					echo "gagal delete karyawan";
	
				}
			}
			else{
				echo "gagal delete user";
			}
			
		}
		function updateevent($id_event,$judul_event,$isi_event,$tanggal_event,$foto){
		$sqlupdate =  $this->db->query("update mst_event set judul_event = '$judul_event', isi_event = '$isi_event', tanggal_event = '$tanggal_event'
		,photo_event = '$foto' where id_event = '$id_event'");
		if($sqlupdate){
		redirect('menuadmin/event');
		
		}
			else{
					echo "gagal Update event";
	
				
					}
		
		}
		function updatetanpafotoevent($id_event,$judul_event,$isi_event,$tanggal_event){
		$sqlupdate =  $this->db->query("update mst_event set judul_event = '$judul_event', isi_event = '$isi_event', tanggal_event = '$tanggal_event'
		where id_event = '$id_event'");
		if($sqlupdate){
		redirect('menuadmin/event');
		
		}
			else{
					echo "gagal Update event";
	
				
					}
		
		}
		function delete_event($id_event){ 
			$sql1 = $this->db->delete('mst_event',array('id_event' => $id_event));
			if($sql1){
				
					redirect('menuadmin/event');
				}
				else{
					echo "gagal delete event";
	
				
					}
					
		
		}
		function ambiljenisproduk(){
			$ambiljenisproduk = $this->db->query("select id_jenisproduk,nama_jenisproduk,keterangan
			from mst_jenisproduk ");
			if($ambiljenisproduk->num_rows()> 0){
				foreach($ambiljenisproduk->result() as $data1){
					$hjenisproduk[] = $data1;
				}
				return $hjenisproduk;
			}
		}
		function delete_jenisproduk($id_jenisproduk){ 
			$sql1 = $this->db->delete('mst_jenisproduk',array('id_jenisproduk' => $id_jenisproduk));
			if($sql1){
				
					redirect('menuadmin/jenisproduk');
				}
				else{
					echo "gagal delete jenis produk";
	
				
					}
					
		
		}
		function tambahjenisproduk(){
			$nama_jenisproduk = $this->input->post('nama_jenisproduk');
			$keterangan = $this->input->post('keterangan');
			$data = array(
					'nama_jenisproduk' => $nama_jenisproduk,
					'keterangan' => $keterangan,
					
			);
			$this->db->insert('mst_jenisproduk',$data);
		}
		function selectjenisproduk($id_jenisproduk){
			return $selectjenisproduk = $this->db->query("select id_jenisproduk,nama_jenisproduk,keterangan from mst_jenisproduk where id_jenisproduk
			= '$id_jenisproduk'")->row();
		
		}
		function updatejenisproduk($id_jenisproduk,$nama_jenisproduk,$keterangan){
			$sqlupdate =  $this->db->query("update mst_jenisproduk set nama_jenisproduk = '$nama_jenisproduk',keterangan = '$keterangan' where id_jenisproduk = '$id_jenisproduk'");
		if($sqlupdate){
		redirect('menuadmin/jenisproduk');
		
		}
			else{
					echo "gagal Update event";
	
				
					}
		}
		function ambilkatalog(){
			$ambilkatalog = $this->db->query("select mst_katalog.id_katalog, mst_katalog.nama_katalog,mst_jenisproduk.nama_jenisproduk from mst_katalog,mst_jenisproduk where 
			mst_jenisproduk.id_jenisproduk =  mst_katalog.id_jenisproduk");
			if($ambilkatalog->num_rows()> 0){
				foreach($ambilkatalog->result() as $data1){
					$hkatalog[] = $data1;
				}
				return $hkatalog;
			}
		}
		function selectkatalog($id_katalog){
			return $selectkatalog = $this->db->query("select mst_katalog.id_katalog, mst_katalog.nama_katalog,mst_katalog.link_katalog,mst_katalog.tanggal_katalog,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk from mst_katalog,mst_jenisproduk where 
			mst_jenisproduk.id_jenisproduk =  mst_katalog.id_jenisproduk and mst_katalog.id_katalog = '$id_katalog' ")->row();	
		}
		
		function tambahkatalog(){
			$nama_katalog =  $this->input->post('nama_katalog');
			$link_katalog =  $this->input->post('link_katalog');
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$tanggal_katalog = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			
			$id_jenisproduk =  $this->input->post('id_jenisproduk');
			$data = array(
				'nama_katalog' => $nama_katalog,
				'link_katalog' => $link_katalog,
				'tanggal_katalog' => $tanggal_katalog,
				'id_jenisproduk' => $id_jenisproduk,
			);
			$this->db->insert('mst_katalog',$data);
		}
		
		function deletekatalog($id_katalog){
			$hapus = $this->db->delete('mst_katalog',array('id_katalog' => $id_katalog));
			if($hapus){
				redirect('menuadmin/katalog');
			}else{
					echo "gagal delete jenis produk";
			}
		}
		function updatekatalog($id_katalog){
			
			$nama_katalog =  $this->input->post('nama_katalog');
			$link_katalog =  $this->input->post('link_katalog');
			$dt1 = array(
			$this->input->post('tgl1'),
			$this->input->post('bln1'),
			$this->input->post('thn1'));
			$tanggal_katalog = $dt1[2]."-".$dt1[1]."-".$dt1[0];
			
			$id_jenisproduk =  $this->input->post('id_jenisproduk');
			$data = array(
				'nama_katalog' => $nama_katalog,
				'link_katalog' => $link_katalog,
				'tanggal_katalog' => $tanggal_katalog,
				'id_jenisproduk' => $id_jenisproduk,
			);
			$this->db->where('id_katalog',$id_katalog);
			$this->db->update('mst_katalog',$data);
			
		}
		function ambilprofil(){
			$ambilprofil = $this->db->query("select deskripsi,link_fb,link_twitter,link_ins,photo from mst_profil where keterangan = 'profil' ");
			if($ambilprofil->num_rows()> 0){
				redirect('menuadmin/updateprofil');
			}else{
				redirect('menuadmin/tambahprofil');
			}
		}
		function selectprofil(){
				return $sql = $this->db->query("select deskripsi,link_fb,link_twitter,link_ins,photo from mst_profil where keterangan = 'profil'")->row();
		}
		function updateprofil($deskripsi,$link_fb,$link_twitter,$link_ins,$foto){
			$sql = $this->db->query("update mst_profil set deskripsi = '$deskripsi',link_fb = '$link_fb',link_twitter = '$link_twitter', link_ins = '$link_ins', 
			photo = '$foto' where keterangan = 'profil'");
			if($sql){
			redirect('menuadmin/profil');
			}
			else{
		    echo "gagal update";
			}
		}
		function updatetanpafotoprofil($deskripsi,$email,$link_fb,$link_twitter,$link_ins){
			$sql = $this->db->query("update mst_profil set deskripsi = '$deskripsi',link_fb = '$link_fb',link_twitter =  '$link_twitter', link_ins = '$link_ins'
			where keterangan = 'profil'");
			if($sql){
			redirect('menuadmin/profil');
			}
			else{
		    echo "gagal update";
			}
		}
		function ambilhowtoorder(){
			$ambilhowtoorder = $this->db->query("select deskripsi,photo from mst_profil where keterangan = 'howtoorder' ");
			if($ambilhowtoorder->num_rows()> 0){
				redirect('menuadmin/updatehowtoorder');
			}else{
				redirect('menuadmin/tambahhowtoorder');
			}
		}
		function updatehowtoorder($deskripsi,$foto){
			$sql = $this->db->query("update mst_profil set deskripsi = '$deskripsi',photo = '$foto' where keterangan = 'howtoorder'");
			if($sql){
			redirect('menuadmin/howtoorder');
			}
			else{
		    echo "gagal update";
			}
		}
		function updatetanpafotohowtoorder($deskripsi,$foto){
			$sql = $this->db->query("update mst_profil set deskripsi = '$deskripsi' where keterangan = 'howtoorder'");
			if($sql){
			redirect('menuadmin/howtoorder');
			}
			else{
		    echo "gagal update";
			}
		}
		function selecthowtoorder(){
				return $sql = $this->db->query("select deskripsi,photo from mst_profil where keterangan = 'howtoorder'")->row();
		}
		function ambilproduk(){
			$ambilproduk = $this->db->query("select mst_produk.id_produk,mst_produk.nama_produk,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk
			,mst_produk.deskripsi,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan from mst_jenisproduk, mst_produk
			where mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk");
			if($ambilproduk->num_rows()> 0){
				foreach($ambilproduk->result() as $data1){
					$hproduk[] = $data1;
				}
				return $hproduk;
			}
			}
			function selectproduk($id_produk){
				return $sql = $this->db->query("select mst_produk.id_produk,mst_produk.nama_produk,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk
			,mst_produk.deskripsi,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan from mst_jenisproduk, mst_produk
			where mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk and mst_produk.id_produk = '$id_produk' ")->row();
		}
		
		function delete_produk($id_produk){
			$hapus = $this->db->delete('mst_produk',array('id_produk' => $id_produk));
			if($hapus){
				redirect('menuadmin/produk');
			}else{
					echo "gagal delete produk";
			}
		}
		
		function updateproduk($id_produk,$deskripsi,$nama_produk,$id_jenisproduk,$harga_produk,$jumlah_produk,$satuan_produk,$dari_tanggal,$sampai_tanggal,$kategori,$persetujuan,$foto){
		
			$sql = $this->db->query("update mst_produk set nama_produk = '$nama_produk',id_jenisproduk = '$id_jenisproduk',deskripsi = '$deskripsi'
			,harga_produk = '$harga_produk'
          ,jumlah_produk = '$jumlah_produk',satuan_produk = '$satuan_produk',dari_tanggal = '$dari_tanggal',sampai_tanggal = '$sampai_tanggal',
			kategori = '$kategori', photo = '$foto', persetujuan = '$persetujuan' where id_produk = '$id_produk'");
			if($sql){
			redirect('menuadmin/produk');
			}
			else{
		    echo "gagal update";
			}
		}
		function updatetanpafotoproduk($id_produk,$deskripsi,$nama_produk,$id_jenisproduk,$harga_produk,$jumlah_produk,$satuan_produk,$dari_tanggal,$sampai_tanggal,$kategori,$persetujuan){
		
			$sql = $this->db->query("update mst_produk set nama_produk = '$nama_produk',id_jenisproduk = '$id_jenisproduk',deskripsi = '$deskripsi'
			,harga_produk = '$harga_produk'
          ,jumlah_produk = '$jumlah_produk',satuan_produk = '$satuan_produk',dari_tanggal = '$dari_tanggal',sampai_tanggal = '$sampai_tanggal',
			kategori = '$kategori',persetujuan = '$persetujuan' where id_produk = '$id_produk'");
			if($sql){
			redirect('menuadmin/produk');
			}
			else{
		    echo "gagal update";
			}
		}
		function ambilkomunikasi(){
			$ambilkomunikasi = $this->db->query("select id_komunikasi,name,email_dari,email_kepada,isi,tgl_komunikasi,status from mst_komunikasi");
			if($ambilkomunikasi->num_rows()> 0){
				foreach($ambilkomunikasi->result() as $data1){
					$hkomunikasi[] = $data1;
				}
				return $hkomunikasi;
			}
		}
		function selectkomunikasi($id_komunikasi){
			return $ambilkomunikasi = $this->db->query("select id_komunikasi,name,email_dari,email_kepada,isi,tgl_komunikasi,status from mst_komunikasi where id_komunikasi = '$id_komunikasi'")->row();
			
		}
		function updatestatuskomunikasi($id_komunikasi){
			$sql = $this->db->query("update mst_komunikasi set status = 'Telah Di balas' where id_komunikasi = '$id_komunikasi'");
			if($sql){
			redirect('menuadmin/komunikasi');
			}
			else{
		    echo "gagal update";
			}
		}
		function persetujuan($id_produk,$persetujuan){
			$sql = $this->db->query("update mst_produk set persetujuan = '$persetujuan' where id_produk = '$id_produk'");
			if($sql){
			redirect('menuadmin/produk');
			}
			else{
		    echo "gagal update";
			}
			
		
		}
		function ambilpemilik(){
			return $ambilpemilik = $this->db->query("select mst_user.nik,mst_karyawan.nama_karyawan,mst_karyawan.nama_karyawan,mst_karyawan.jabatan_karyawan from mst_karyawan
			,mst_user where mst_user.akses = 'Pemilik' and mst_user.nik = mst_karyawan.nik")->row();
		}
		function ambilproduk2($dari_tanggal,$sampai_tanggal){
			$ambilproduk = $this->db->query("select mst_produk.id_produk,mst_produk.nama_produk,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk
			,mst_produk.deskripsi,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan from mst_jenisproduk, mst_produk
			where mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk and mst_produk.dari_tanggal >= '$dari_tanggal' and mst_produk.dari_tanggal <= '$sampai_tanggal'");
			if($ambilproduk->num_rows()> 0){
				foreach($ambilproduk->result() as $data1){
					$hproduk[] = $data1;
				}
				return $hproduk;
			}
			}
			function ambilpromosi($dari_tanggal,$sampai_tanggal){
			$ambilpromosi = $this->db->query("select mst_produk.id_produk ,mst_produk.nama_produk,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan,mst_produk.jumlah_show,
			mst_jenisproduk.nama_jenisproduk,
			count(mst_pemesanan.id_produk) as jumlah_pesanan
			from mst_produk  
			left join mst_pemesanan on mst_produk.id_produk = mst_pemesanan.id_produk 
			left join mst_jenisproduk on mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk 
			where mst_produk.dari_tanggal >= '$dari_tanggal' and mst_produk.dari_tanggal <= '$sampai_tanggal'
			group by mst_produk.id_produk ,mst_produk.nama_produk, mst_jenisproduk.id_jenisproduk
			order by count(mst_pemesanan.id_produk)");
			if($ambilpromosi->num_rows()> 0){
				foreach($ambilpromosi->result() as $data1){
					$hpromosi[] = $data1;
				}
				return $hpromosi;
			}
			}
	
		function daftarpemesan(){
			$daftarpemesan = $this->db->query("select mst_member.nik,mst_member.nama_member,mst_pemesanan.id_pemesanan, mst_produk.nama_produk,mst_pemesanan.jumlah_produk
,mst_pemesanan.total_harga,
mst_pemesanan.tanggal_pemesanan, mst_pemesanan.persetujuan ,mst_produk.harga_produk
from mst_pemesanan,mst_produk,mst_member where mst_produk.id_produk = mst_pemesanan.id_produk
and mst_pemesanan.nik = mst_member.nik");
			if($daftarpemesan->num_rows()> 0){
				foreach($daftarpemesan->result() as $data){
					$hpemesan[] = $data;
				}
				return $hpemesan;
			}
		}
		function selectpemesan($id_pemesanan){
			return $selectpemesan= $this->db->query("select mst_member.nik,mst_member.nama_member,mst_pemesanan.id_pemesanan, 
			mst_produk.nama_produk,mst_pemesanan.jumlah_produk,mst_produk.harga_produk,
mst_pemesanan.total_harga,
mst_pemesanan.tanggal_pemesanan, mst_pemesanan.persetujuan
from mst_pemesanan,mst_produk,mst_member where mst_produk.id_produk = mst_pemesanan.id_produk
and mst_pemesanan.nik = mst_member.nik and mst_pemesanan.id_pemesanan = '$id_pemesanan'")->row();
		}
		function submit_persetujuanpemesanan(){
			$id_pemesanan = $this->input->post('id_pemesanan');
			$persetujuan = $this->input->post('persetujuan');
			$sql = $this->db->query("update mst_pemesanan set persetujuan = '$persetujuan' where id_pemesanan = '$id_pemesanan'");
			if($sql){
				redirect('menuadmin/daftarpemesan');
			}
			}
			function member(){
			$member= $this->db->query("select mst_user.nik,mst_user.username,mst_member.nama_member,mst_user.password,mst_member.tgl_lahir,
			mst_member.alamat_member,mst_member.jk_member,mst_member.email_member
			,mst_member.tlpn_member
			,mst_member.photo_member,mst_member.nama_bank,mst_member.rekening_bank,mst_user.status,mst_user.akses 
			from mst_user,mst_member where mst_user.nik =  mst_member.nik");
			if($member->num_rows()> 0){
				foreach($member->result() as $data){
					$hmember[] = $data;
				}
				return $hmember;
			}
		}
		
		function selectmember($nik){
			return $sql = $this->db->query("select mst_user.nik,mst_user.username,mst_member.nama_member,mst_user.password,mst_member.tgl_lahir,
			mst_member.alamat_member,mst_member.jk_member,mst_member.email_member
			,mst_member.tlpn_member
			,mst_member.photo_member,mst_member.nama_bank,mst_member.rekening_bank,mst_user.status,mst_user.akses 
			from mst_user,mst_member where mst_user.nik =  mst_member.nik
			and mst_user.status = 'Aktif' and mst_user.akses = 'Member' and mst_user.nik = '$nik'")->row();
		}
		}

		