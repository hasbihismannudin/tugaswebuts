<?php
	class Mpublic extends CI_Model{
		function ambilproduktop3(){
			$ambilproduktop3 = $this->db->query("Select  id_produk,jumlah_show,nama_produk ,photo,sampai_tanggal,deskripsi,harga_produk,satuan_produk,jumlah_produk from mst_produk order by dari_tanggal DESC  limit 3");
			if($ambilproduktop3->num_rows()> 0){
				foreach($ambilproduktop3->result() as $data){
					$hproduktop3[] = $data;
				}
				return $hproduktop3;
			}
		}
		
		function selectprofil(){
				return $sql = $this->db->query("select deskripsi,link_fb,link_twitter,link_ins,photo from mst_profil where keterangan = 'profil'")->row();
		}
		function selecthowtoorder(){
				return $sql = $this->db->query("select deskripsi,link_fb,link_twitter,link_ins,photo from mst_profil where keterangan = 'howtoorder'")->row();
		}
		function ambilevent(){
			return $ambilevent = $this->db->query("select id_event,judul_event,isi_event,tanggal_event,photo_event
						from mst_event order by tanggal_event DESC  limit 1")->row();
			
		}
		function ambilsemuaevent(){
			$ambilsemuaevent = $this->db->query("select id_event,judul_event,isi_event,tanggal_event,photo_event
						from mst_event order by tanggal_event DESC ");
			if($ambilsemuaevent->num_rows()> 0){
				foreach($ambilsemuaevent->result() as $data){
					$hevent[] = $data;
				}
				return $hevent;
			}
		}
		function selectevent($id_event){
			return $selectevent = $this->db->query("select id_event,judul_event,isi_event,tanggal_event,photo_event
		
			from mst_event where id_event = '$id_event' ")->row();	
		}
		function selectproduk($id_produk){
				
				return $sql = $this->db->query("select mst_produk.id_produk,mst_produk.nama_produk,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk
			,mst_produk.deskripsi,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan,mst_produk.jumlah_show from mst_jenisproduk, mst_produk
			where mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk and mst_produk.id_produk = '$id_produk' ")->row();
			
		}
		function selectpromo($id_produk){
				return $sql = $this->db->query("select mst_produk.id_produk,mst_produk.nama_produk,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk
			,mst_produk.deskripsi,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan,mst_produk.jumlah_show from mst_jenisproduk, mst_produk
			where mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk and mst_produk.id_produk = '$id_produk' and mst_produk.kategori = 'Promo'")->row();
		}
		function ambilprodukreguler(){
			$ambilproduk = $this->db->query("select mst_produk.id_produk,mst_produk.nama_produk,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk
			,mst_produk.deskripsi,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan,mst_produk.jumlah_show from mst_jenisproduk, mst_produk
			where mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk and mst_produk.kategori = 'Reguler' ");
			if($ambilproduk->num_rows()> 0){
				foreach($ambilproduk->result() as $data1){
					$hproduk[] = $data1;
				}
				return $hproduk;
			}
			}
			function ambilprodukpromo(){
			$ambilproduk = $this->db->query("select mst_produk.id_produk,mst_produk.nama_produk,mst_jenisproduk.id_jenisproduk,mst_jenisproduk.nama_jenisproduk
			,mst_produk.deskripsi,mst_produk.harga_produk,mst_produk.jumlah_produk,mst_produk.satuan_produk,mst_produk.dari_tanggal,
			mst_produk.sampai_tanggal,mst_produk.kategori,mst_produk.photo,mst_produk.persetujuan,mst_produk.jumlah_show from mst_jenisproduk, mst_produk
			where mst_jenisproduk.id_jenisproduk = mst_produk.id_jenisproduk and mst_produk.kategori = 'promo' ");
			if($ambilproduk->num_rows()> 0){
				foreach($ambilproduk->result() as $data1){
					$hprodukpromo[] = $data1;
				}
				return $hprodukpromo;
			}
			}
		function ambilkatalogtop3(){
			$ambilkatalogtop3 = $this->db->query("Select mst_katalog.id_katalog,mst_katalog.nama_katalog,mst_katalog.link_katalog,mst_katalog.tanggal_katalog
			,mst_jenisproduk.nama_jenisproduk from mst_katalog,mst_jenisproduk where mst_katalog.id_jenisproduk = mst_jenisproduk.id_jenisproduk order by tanggal_katalog DESC ");
			if($ambilkatalogtop3->num_rows()> 0){
				foreach($ambilkatalogtop3->result() as $data){
					$hkatalogtop3[] = $data;
				}
				return $hkatalogtop3;
			}
		}
		function ambilnik(){
			return $ambilnik = $this->db->query("select nik
						from mst_member order by nik DESC  limit 1")->row();
			
		}
		function login(){
			 $username = $this->input->post('username');
        $password_member = md5($this->input->post('password_member'));
        $query = $this->db->query("select mst_user.username, mst_user.nik,mst_member.nama_member,mst_user.password,mst_user.status,mst_user.akses
		from mst_user,mst_member where mst_user.nik =  mst_member.nik and
        mst_user.status = 'Aktif' and mst_user.akses = 'Member' and mst_user.username = '$username' and mst_user.password = '$password_member' ");

		if($query->num_rows()==1) // jika data user benar
		{
			foreach($query->result() as $data2){
				$data = array(
				'nik' => $data2->nik,
				'nama' => $data2->username,
				'akses' => $data2->akses,
				'is_logged_in' => true
				);
			$this->session->set_userdata($data);
			redirect('publicdesign/myaccount');
			}
				
		}
	   else // username atau password salah
		{
		redirect('publicdesign/home');
						
		}
  
		}
		function selectmyaccount($nik){
			return $sql = $this->db->query("select mst_user.nik,mst_user.username,mst_member.nama_member,mst_user.password,mst_member.tgl_lahir,
			mst_member.alamat_member,mst_member.jk_member,mst_member.email_member
			,mst_member.tlpn_member
			,mst_member.photo_member,mst_member.nama_bank,mst_member.rekening_bank,mst_user.status,mst_user.akses 
			from mst_user,mst_member where mst_user.nik =  mst_member.nik
			and mst_user.status = 'Aktif' and mst_user.akses = 'Member' and mst_user.nik = '$nik'")->row();
		}
		function update_member($nik,$nama_member,$username,$password_baru,$tgl_lahir,$alamat_member
				,$jk_member,$email_member,$tlpn_member,$akses,$status,$nama_bank,$rekening_bank,$foto){
			$sql = $this->db->query("update mst_member set nama_member = '$nama_member',tgl_lahir = '$tgl_lahir'
			,alamat_member = '$alamat_member',jk_member = '$jk_member',email_member = '$email_member'
			,tlpn_member = '$tlpn_member',photo_member = '$foto',nama_bank = '$nama_bank',rekening_bank = '$rekening_bank'
			where nik = '$nik'");
			if($sql){
			if($password_baru == ""){
				$user = $this->db->query("update mst_user set username = '$username',akses = '$akses'
				where nik = '$nik' and akses = 'Member'");
				if($user){
					redirect('publicdesign/myaccount');
				}
				else{
				ECHO "GAGAL USER";
				}
			}else{
				$user = $this->db->query("update mst_user set username = '$username',password = '$password_baru'
				where nik = '$nik' and akses = 'Member'");
				if($user){
					redirect('publicdesign/myaccount');
				}
				else{
				ECHO "GAGAL USER";
				}
			}}
			else{
				echo "gagal";
			}
		}
		function updatetanpamember($nik,$nama_member,$username,$password_baru,$tgl_lahir,$alamat_member
				,$jk_member,$email_member,$tlpn_member,$akses,$status,$nama_bank,$rekening_bank){
			$sql = $this->db->query("update mst_member set nama_member = '$nama_member',tgl_lahir = '$tgl_lahir'
			,alamat_member = '$alamat_member',jk_member = '$jk_member',email_member = '$email_member'
			,tlpn_member = '$tlpn_member',nama_bank = '$nama_bank',rekening_bank = '$rekening_bank'
			where nik = '$nik'");
			if($sql){
			if($password_baru == ""){
				$user = $this->db->query("update mst_user set username = '$username',akses = '$akses'
				where nik = '$nik' and akses = 'Member'");
				if($user){
					redirect('publicdesign/myaccount');
				}
				else{
				ECHO "GAGAL USER";
				}
			}else{
				$user = $this->db->query("update mst_user set username = '$username',password = '$password_baru'
				where nik = '$nik' and akses = 'Member'");
				if($user){
					redirect('publicdesign/myaccount');
				}
				else{
				ECHO "GAGAL USER";
				}
			}}
			else{
				echo "gagal";
			}
		}
		function ambilpemesananlist($nik){
			$ambilpemesananlist = $this->db->query("select mst_pemesanan.id_pemesanan, mst_produk.nama_produk,mst_pemesanan.jumlah_produk,mst_pemesanan.total_harga,
mst_pemesanan.tanggal_pemesanan, mst_pemesanan.persetujuan ,mst_produk.harga_produk
from mst_pemesanan,mst_produk where mst_produk.id_produk = mst_pemesanan.id_produk
and mst_pemesanan.nik = '$nik'");
			if($ambilpemesananlist->num_rows()> 0){
				foreach($ambilpemesananlist->result() as $data){
					$hlist[] = $data;
				}
				return $hlist;
			}
		}
		function submit_pemesanan(){
			$id_produk = $this->input->post('id_produk');
			$nama_produk = $this->input->post('nama_produk');
			$harga_produk = $this->input->post('harga_produk');
			$jumlah_produk = $this->input->post('jumlah_produk');
			$total_harga = $this->input->post('total_harga');
			$date = date("Y-m-d h:i:s"); 
			$nik = $this->session->userdata('nik');
			$sql = $this->db->query("insert into mst_pemesanan(id_produk,jumlah_produk,total_harga,tanggal_pemesanan
			,nik,persetujuan)values('$id_produk','$jumlah_produk','$total_harga',
			'$date','$nik','Diproses')");
			if($sql){
				redirect('publicdesign/myaccount');
			}else{
				echo "gagal";
			}
			
			
		}
		
	}