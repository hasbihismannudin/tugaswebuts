<?php
class Mauth extends CI_Model{
	function validate()
 {
  $login = $this->input->post('login');
        $password = md5($this->input->post('password'));
        $query = $this->db->query("select mst_user.username, mst_user.nik,mst_karyawan.nama_karyawan,mst_user.password,mst_user.status,mst_user.akses from mst_user,mst_karyawan where mst_user.nik =  mst_karyawan.nik and
        mst_user.status = 'Aktif' and mst_user.username = '$login' and mst_user.password = '$password' ");

		if($query->num_rows()==1) // jika data user benar
		{
			foreach($query->result() as $data2){
				$data = array(
				'nik' => $data2->nik,
				'nama' => $data2->nama_karyawan,
				'akses' => $data2->akses,
				'is_logged_in' => true
				);
			$this->session->set_userdata($data);
			
			redirect('menuadmin');
			
			}
				
		}
	   else // username atau password salah
		{
		redirect('auth');
						
		}
  
  
 }
 
}